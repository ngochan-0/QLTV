﻿namespace QLThuVien
{
    partial class QLMuonTra
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.txtTenDG_TTDG = new System.Windows.Forms.TextBox();
            this.txtMaDG_TTDG = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.date_NgayTra_PM = new System.Windows.Forms.DateTimePicker();
            this.date_NgayMuon_PM = new System.Windows.Forms.DateTimePicker();
            this.cbMaDG_PM = new System.Windows.Forms.ComboBox();
            this.cbTenSach_PM = new System.Windows.Forms.ComboBox();
            this.txtTTSach_PM = new System.Windows.Forms.TextBox();
            this.txtMaPM_PM = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.lbNgayMuon = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.raMaDG_QLMuonTra = new System.Windows.Forms.RadioButton();
            this.raMaSach_QLMuonTra = new System.Windows.Forms.RadioButton();
            this.txtTimKiemMuonTra = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtSLCon_TTS = new System.Windows.Forms.TextBox();
            this.txtTenTG_TTS = new System.Windows.Forms.TextBox();
            this.txtTenSach_TTS = new System.Windows.Forms.TextBox();
            this.txtMaSach_TTS = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btHuy_QLMuonTra = new System.Windows.Forms.Button();
            this.btCapNhat_QLMuonTra = new System.Windows.Forms.Button();
            this.btGiaHan_QLMuonTra = new System.Windows.Forms.Button();
            this.btTra_QLMuonTra = new System.Windows.Forms.Button();
            this.btMuon_QLMuonTra = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgvMuonTra = new System.Windows.Forms.DataGridView();
            this.groupBox12.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMuonTra)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.txtTenDG_TTDG);
            this.groupBox12.Controls.Add(this.txtMaDG_TTDG);
            this.groupBox12.Controls.Add(this.label53);
            this.groupBox12.Controls.Add(this.label54);
            this.groupBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.Location = new System.Drawing.Point(17, 10);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox12.Size = new System.Drawing.Size(297, 116);
            this.groupBox12.TabIndex = 55;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Thông Tin Độc Giả";
            // 
            // txtTenDG_TTDG
            // 
            this.txtTenDG_TTDG.Location = new System.Drawing.Point(108, 69);
            this.txtTenDG_TTDG.Margin = new System.Windows.Forms.Padding(4);
            this.txtTenDG_TTDG.Name = "txtTenDG_TTDG";
            this.txtTenDG_TTDG.Size = new System.Drawing.Size(181, 30);
            this.txtTenDG_TTDG.TabIndex = 53;
            // 
            // txtMaDG_TTDG
            // 
            this.txtMaDG_TTDG.Location = new System.Drawing.Point(108, 30);
            this.txtMaDG_TTDG.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaDG_TTDG.Name = "txtMaDG_TTDG";
            this.txtMaDG_TTDG.Size = new System.Drawing.Size(181, 30);
            this.txtMaDG_TTDG.TabIndex = 52;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.ForeColor = System.Drawing.Color.Black;
            this.label53.Location = new System.Drawing.Point(17, 70);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(69, 24);
            this.label53.TabIndex = 36;
            this.label53.Text = "Tên ĐG";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.ForeColor = System.Drawing.Color.Black;
            this.label54.Location = new System.Drawing.Point(17, 30);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(67, 24);
            this.label54.TabIndex = 34;
            this.label54.Text = "Mã ĐG";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.date_NgayTra_PM);
            this.groupBox6.Controls.Add(this.date_NgayMuon_PM);
            this.groupBox6.Controls.Add(this.cbMaDG_PM);
            this.groupBox6.Controls.Add(this.cbTenSach_PM);
            this.groupBox6.Controls.Add(this.txtTTSach_PM);
            this.groupBox6.Controls.Add(this.txtMaPM_PM);
            this.groupBox6.Controls.Add(this.label35);
            this.groupBox6.Controls.Add(this.label34);
            this.groupBox6.Controls.Add(this.lbNgayMuon);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Controls.Add(this.label31);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(345, 134);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox6.Size = new System.Drawing.Size(777, 166);
            this.groupBox6.TabIndex = 56;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Phiếu Mượn";
            // 
            // date_NgayTra_PM
            // 
            this.date_NgayTra_PM.Location = new System.Drawing.Point(495, 79);
            this.date_NgayTra_PM.Margin = new System.Windows.Forms.Padding(4);
            this.date_NgayTra_PM.Name = "date_NgayTra_PM";
            this.date_NgayTra_PM.Size = new System.Drawing.Size(275, 30);
            this.date_NgayTra_PM.TabIndex = 63;
            // 
            // date_NgayMuon_PM
            // 
            this.date_NgayMuon_PM.Location = new System.Drawing.Point(495, 36);
            this.date_NgayMuon_PM.Margin = new System.Windows.Forms.Padding(4);
            this.date_NgayMuon_PM.Name = "date_NgayMuon_PM";
            this.date_NgayMuon_PM.Size = new System.Drawing.Size(275, 30);
            this.date_NgayMuon_PM.TabIndex = 62;
            // 
            // cbMaDG_PM
            // 
            this.cbMaDG_PM.FormattingEnabled = true;
            this.cbMaDG_PM.Location = new System.Drawing.Point(108, 118);
            this.cbMaDG_PM.Margin = new System.Windows.Forms.Padding(4);
            this.cbMaDG_PM.Name = "cbMaDG_PM";
            this.cbMaDG_PM.Size = new System.Drawing.Size(209, 33);
            this.cbMaDG_PM.TabIndex = 61;
            this.cbMaDG_PM.SelectedIndexChanged += new System.EventHandler(this.cbMaDG_PM_SelectedIndexChanged);
            // 
            // cbTenSach_PM
            // 
            this.cbTenSach_PM.FormattingEnabled = true;
            this.cbTenSach_PM.Location = new System.Drawing.Point(108, 75);
            this.cbTenSach_PM.Margin = new System.Windows.Forms.Padding(4);
            this.cbTenSach_PM.Name = "cbTenSach_PM";
            this.cbTenSach_PM.Size = new System.Drawing.Size(209, 33);
            this.cbTenSach_PM.TabIndex = 60;
            this.cbTenSach_PM.SelectedIndexChanged += new System.EventHandler(this.cbTenSach_PM_SelectedIndexChanged);
            // 
            // txtTTSach_PM
            // 
            this.txtTTSach_PM.Location = new System.Drawing.Point(495, 121);
            this.txtTTSach_PM.Margin = new System.Windows.Forms.Padding(4);
            this.txtTTSach_PM.Name = "txtTTSach_PM";
            this.txtTTSach_PM.Size = new System.Drawing.Size(275, 30);
            this.txtTTSach_PM.TabIndex = 59;
            // 
            // txtMaPM_PM
            // 
            this.txtMaPM_PM.Location = new System.Drawing.Point(108, 33);
            this.txtMaPM_PM.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaPM_PM.Name = "txtMaPM_PM";
            this.txtMaPM_PM.Size = new System.Drawing.Size(209, 30);
            this.txtMaPM_PM.TabIndex = 54;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Black;
            this.label35.Location = new System.Drawing.Point(345, 121);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(141, 24);
            this.label35.TabIndex = 51;
            this.label35.Text = "Tình Trạng Sách";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(404, 79);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(82, 24);
            this.label34.TabIndex = 48;
            this.label34.Text = "Ngày Trả";
            // 
            // lbNgayMuon
            // 
            this.lbNgayMuon.AutoSize = true;
            this.lbNgayMuon.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbNgayMuon.ForeColor = System.Drawing.Color.Black;
            this.lbNgayMuon.Location = new System.Drawing.Point(379, 37);
            this.lbNgayMuon.Name = "lbNgayMuon";
            this.lbNgayMuon.Size = new System.Drawing.Size(108, 24);
            this.lbNgayMuon.TabIndex = 46;
            this.lbNgayMuon.Text = "Ngày Mượn";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Black;
            this.label32.Location = new System.Drawing.Point(11, 121);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(67, 24);
            this.label32.TabIndex = 44;
            this.label32.Text = "Mã ĐG";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Black;
            this.label30.Location = new System.Drawing.Point(11, 78);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(82, 24);
            this.label30.TabIndex = 42;
            this.label30.Text = "Tên Sách";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.Black;
            this.label31.Location = new System.Drawing.Point(11, 34);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(69, 24);
            this.label31.TabIndex = 41;
            this.label31.Text = "Mã PM";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.raMaDG_QLMuonTra);
            this.groupBox5.Controls.Add(this.raMaSach_QLMuonTra);
            this.groupBox5.Controls.Add(this.txtTimKiemMuonTra);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(384, 10);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox5.Size = new System.Drawing.Size(739, 94);
            this.groupBox5.TabIndex = 57;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Tìm Kiếm";
            // 
            // raMaDG_QLMuonTra
            // 
            this.raMaDG_QLMuonTra.AutoSize = true;
            this.raMaDG_QLMuonTra.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raMaDG_QLMuonTra.Location = new System.Drawing.Point(27, 36);
            this.raMaDG_QLMuonTra.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.raMaDG_QLMuonTra.Name = "raMaDG_QLMuonTra";
            this.raMaDG_QLMuonTra.Size = new System.Drawing.Size(88, 28);
            this.raMaDG_QLMuonTra.TabIndex = 55;
            this.raMaDG_QLMuonTra.TabStop = true;
            this.raMaDG_QLMuonTra.Text = "Mã ĐG";
            this.raMaDG_QLMuonTra.UseVisualStyleBackColor = true;
            // 
            // raMaSach_QLMuonTra
            // 
            this.raMaSach_QLMuonTra.AutoSize = true;
            this.raMaSach_QLMuonTra.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raMaSach_QLMuonTra.Location = new System.Drawing.Point(173, 36);
            this.raMaSach_QLMuonTra.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.raMaSach_QLMuonTra.Name = "raMaSach_QLMuonTra";
            this.raMaSach_QLMuonTra.Size = new System.Drawing.Size(101, 28);
            this.raMaSach_QLMuonTra.TabIndex = 56;
            this.raMaSach_QLMuonTra.TabStop = true;
            this.raMaSach_QLMuonTra.Text = "Mã Sách";
            this.raMaSach_QLMuonTra.UseVisualStyleBackColor = true;
            // 
            // txtTimKiemMuonTra
            // 
            this.txtTimKiemMuonTra.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimKiemMuonTra.Location = new System.Drawing.Point(319, 38);
            this.txtTimKiemMuonTra.Margin = new System.Windows.Forms.Padding(4);
            this.txtTimKiemMuonTra.Name = "txtTimKiemMuonTra";
            this.txtTimKiemMuonTra.Size = new System.Drawing.Size(351, 30);
            this.txtTimKiemMuonTra.TabIndex = 54;
            this.txtTimKiemMuonTra.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtTimKiemMuonTra_KeyUp);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtSLCon_TTS);
            this.groupBox4.Controls.Add(this.txtTenTG_TTS);
            this.groupBox4.Controls.Add(this.txtTenSach_TTS);
            this.groupBox4.Controls.Add(this.txtMaSach_TTS);
            this.groupBox4.Controls.Add(this.label29);
            this.groupBox4.Controls.Add(this.label28);
            this.groupBox4.Controls.Add(this.label27);
            this.groupBox4.Controls.Add(this.label26);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(12, 134);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Size = new System.Drawing.Size(297, 198);
            this.groupBox4.TabIndex = 54;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Thông Tin Sách";
            // 
            // txtSLCon_TTS
            // 
            this.txtSLCon_TTS.Location = new System.Drawing.Point(101, 158);
            this.txtSLCon_TTS.Margin = new System.Windows.Forms.Padding(4);
            this.txtSLCon_TTS.Name = "txtSLCon_TTS";
            this.txtSLCon_TTS.Size = new System.Drawing.Size(181, 30);
            this.txtSLCon_TTS.TabIndex = 61;
            // 
            // txtTenTG_TTS
            // 
            this.txtTenTG_TTS.Location = new System.Drawing.Point(101, 114);
            this.txtTenTG_TTS.Margin = new System.Windows.Forms.Padding(4);
            this.txtTenTG_TTS.Name = "txtTenTG_TTS";
            this.txtTenTG_TTS.Size = new System.Drawing.Size(181, 30);
            this.txtTenTG_TTS.TabIndex = 60;
            // 
            // txtTenSach_TTS
            // 
            this.txtTenSach_TTS.Location = new System.Drawing.Point(103, 73);
            this.txtTenSach_TTS.Margin = new System.Windows.Forms.Padding(4);
            this.txtTenSach_TTS.Name = "txtTenSach_TTS";
            this.txtTenSach_TTS.Size = new System.Drawing.Size(181, 30);
            this.txtTenSach_TTS.TabIndex = 59;
            // 
            // txtMaSach_TTS
            // 
            this.txtMaSach_TTS.Location = new System.Drawing.Point(103, 32);
            this.txtMaSach_TTS.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaSach_TTS.Name = "txtMaSach_TTS";
            this.txtMaSach_TTS.Size = new System.Drawing.Size(181, 30);
            this.txtMaSach_TTS.TabIndex = 58;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.Black;
            this.label29.Location = new System.Drawing.Point(13, 159);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(65, 24);
            this.label29.TabIndex = 40;
            this.label29.Text = "SL Còn";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Black;
            this.label28.Location = new System.Drawing.Point(11, 116);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(66, 24);
            this.label28.TabIndex = 38;
            this.label28.Text = "Tên TG";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(11, 74);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(82, 24);
            this.label27.TabIndex = 36;
            this.label27.Text = "Tên Sách";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(11, 33);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(80, 24);
            this.label26.TabIndex = 34;
            this.label26.Text = "Mã Sách";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btHuy_QLMuonTra);
            this.panel1.Controls.Add(this.btCapNhat_QLMuonTra);
            this.panel1.Controls.Add(this.btGiaHan_QLMuonTra);
            this.panel1.Controls.Add(this.btTra_QLMuonTra);
            this.panel1.Controls.Add(this.btMuon_QLMuonTra);
            this.panel1.Controls.Add(this.groupBox6);
            this.panel1.Controls.Add(this.groupBox12);
            this.panel1.Controls.Add(this.groupBox4);
            this.panel1.Controls.Add(this.groupBox5);
            this.panel1.Location = new System.Drawing.Point(16, 15);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1139, 398);
            this.panel1.TabIndex = 58;
            // 
            // btHuy_QLMuonTra
            // 
            this.btHuy_QLMuonTra.BackColor = System.Drawing.Color.DarkCyan;
            this.btHuy_QLMuonTra.FlatAppearance.BorderSize = 0;
            this.btHuy_QLMuonTra.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_QLMuonTra.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_QLMuonTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btHuy_QLMuonTra.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btHuy_QLMuonTra.ForeColor = System.Drawing.Color.White;
            this.btHuy_QLMuonTra.Location = new System.Drawing.Point(901, 343);
            this.btHuy_QLMuonTra.Margin = new System.Windows.Forms.Padding(4);
            this.btHuy_QLMuonTra.Name = "btHuy_QLMuonTra";
            this.btHuy_QLMuonTra.Size = new System.Drawing.Size(128, 41);
            this.btHuy_QLMuonTra.TabIndex = 62;
            this.btHuy_QLMuonTra.Text = "HỦY";
            this.btHuy_QLMuonTra.UseVisualStyleBackColor = false;
            this.btHuy_QLMuonTra.Click += new System.EventHandler(this.btHuy_QLMuonTra_Click);
            // 
            // btCapNhat_QLMuonTra
            // 
            this.btCapNhat_QLMuonTra.BackColor = System.Drawing.Color.DarkCyan;
            this.btCapNhat_QLMuonTra.FlatAppearance.BorderSize = 0;
            this.btCapNhat_QLMuonTra.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_QLMuonTra.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_QLMuonTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCapNhat_QLMuonTra.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCapNhat_QLMuonTra.ForeColor = System.Drawing.Color.White;
            this.btCapNhat_QLMuonTra.Location = new System.Drawing.Point(703, 343);
            this.btCapNhat_QLMuonTra.Margin = new System.Windows.Forms.Padding(4);
            this.btCapNhat_QLMuonTra.Name = "btCapNhat_QLMuonTra";
            this.btCapNhat_QLMuonTra.Size = new System.Drawing.Size(128, 41);
            this.btCapNhat_QLMuonTra.TabIndex = 61;
            this.btCapNhat_QLMuonTra.Text = "CẬP NHẬT";
            this.btCapNhat_QLMuonTra.UseVisualStyleBackColor = false;
            this.btCapNhat_QLMuonTra.Click += new System.EventHandler(this.btCapNhat_QLMuonTra_Click);
            // 
            // btGiaHan_QLMuonTra
            // 
            this.btGiaHan_QLMuonTra.BackColor = System.Drawing.Color.DarkCyan;
            this.btGiaHan_QLMuonTra.FlatAppearance.BorderSize = 0;
            this.btGiaHan_QLMuonTra.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btGiaHan_QLMuonTra.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btGiaHan_QLMuonTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btGiaHan_QLMuonTra.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btGiaHan_QLMuonTra.ForeColor = System.Drawing.Color.White;
            this.btGiaHan_QLMuonTra.Location = new System.Drawing.Point(504, 343);
            this.btGiaHan_QLMuonTra.Margin = new System.Windows.Forms.Padding(4);
            this.btGiaHan_QLMuonTra.Name = "btGiaHan_QLMuonTra";
            this.btGiaHan_QLMuonTra.Size = new System.Drawing.Size(128, 41);
            this.btGiaHan_QLMuonTra.TabIndex = 60;
            this.btGiaHan_QLMuonTra.Text = "GIA HẠN";
            this.btGiaHan_QLMuonTra.UseVisualStyleBackColor = false;
            this.btGiaHan_QLMuonTra.Click += new System.EventHandler(this.btGiaHan_QLMuonTra_Click);
            // 
            // btTra_QLMuonTra
            // 
            this.btTra_QLMuonTra.BackColor = System.Drawing.Color.DarkCyan;
            this.btTra_QLMuonTra.FlatAppearance.BorderSize = 0;
            this.btTra_QLMuonTra.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btTra_QLMuonTra.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btTra_QLMuonTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btTra_QLMuonTra.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTra_QLMuonTra.ForeColor = System.Drawing.Color.White;
            this.btTra_QLMuonTra.Location = new System.Drawing.Point(305, 343);
            this.btTra_QLMuonTra.Margin = new System.Windows.Forms.Padding(4);
            this.btTra_QLMuonTra.Name = "btTra_QLMuonTra";
            this.btTra_QLMuonTra.Size = new System.Drawing.Size(128, 41);
            this.btTra_QLMuonTra.TabIndex = 59;
            this.btTra_QLMuonTra.Text = "TRẢ";
            this.btTra_QLMuonTra.UseVisualStyleBackColor = false;
            this.btTra_QLMuonTra.Click += new System.EventHandler(this.btTra_QLMuonTra_Click);
            // 
            // btMuon_QLMuonTra
            // 
            this.btMuon_QLMuonTra.BackColor = System.Drawing.Color.DarkCyan;
            this.btMuon_QLMuonTra.FlatAppearance.BorderSize = 0;
            this.btMuon_QLMuonTra.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btMuon_QLMuonTra.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btMuon_QLMuonTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btMuon_QLMuonTra.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btMuon_QLMuonTra.ForeColor = System.Drawing.Color.White;
            this.btMuon_QLMuonTra.Location = new System.Drawing.Point(107, 343);
            this.btMuon_QLMuonTra.Margin = new System.Windows.Forms.Padding(4);
            this.btMuon_QLMuonTra.Name = "btMuon_QLMuonTra";
            this.btMuon_QLMuonTra.Size = new System.Drawing.Size(128, 41);
            this.btMuon_QLMuonTra.TabIndex = 58;
            this.btMuon_QLMuonTra.Text = "MƯỢN";
            this.btMuon_QLMuonTra.UseVisualStyleBackColor = false;
            this.btMuon_QLMuonTra.Click += new System.EventHandler(this.btMuon_QLMuonTra_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.dgvMuonTra);
            this.panel2.Location = new System.Drawing.Point(16, 425);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1139, 258);
            this.panel2.TabIndex = 59;
            // 
            // dgvMuonTra
            // 
            this.dgvMuonTra.AllowUserToAddRows = false;
            this.dgvMuonTra.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMuonTra.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvMuonTra.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvMuonTra.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvMuonTra.Location = new System.Drawing.Point(17, 12);
            this.dgvMuonTra.Margin = new System.Windows.Forms.Padding(4);
            this.dgvMuonTra.Name = "dgvMuonTra";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMuonTra.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvMuonTra.RowHeadersWidth = 51;
            this.dgvMuonTra.Size = new System.Drawing.Size(1105, 233);
            this.dgvMuonTra.TabIndex = 0;
            this.dgvMuonTra.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMuonTra_RowEnter);
            // 
            // QLMuonTra
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "QLMuonTra";
            this.Size = new System.Drawing.Size(1173, 695);
            this.Load += new System.EventHandler(this.QLMuonTra_Load);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvMuonTra)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label lbNgayMuon;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.RadioButton raMaSach_QLMuonTra;
        private System.Windows.Forms.RadioButton raMaDG_QLMuonTra;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtTenDG_TTDG;
        private System.Windows.Forms.TextBox txtMaDG_TTDG;
        private System.Windows.Forms.TextBox txtSLCon_TTS;
        private System.Windows.Forms.TextBox txtTenTG_TTS;
        private System.Windows.Forms.TextBox txtTenSach_TTS;
        private System.Windows.Forms.TextBox txtMaSach_TTS;
        private System.Windows.Forms.DataGridView dgvMuonTra;
        private System.Windows.Forms.TextBox txtTTSach_PM;
        private System.Windows.Forms.TextBox txtMaPM_PM;
        private System.Windows.Forms.TextBox txtTimKiemMuonTra;
        private System.Windows.Forms.Button btHuy_QLMuonTra;
        private System.Windows.Forms.Button btCapNhat_QLMuonTra;
        private System.Windows.Forms.Button btGiaHan_QLMuonTra;
        private System.Windows.Forms.Button btTra_QLMuonTra;
        private System.Windows.Forms.Button btMuon_QLMuonTra;
        private System.Windows.Forms.DateTimePicker date_NgayTra_PM;
        private System.Windows.Forms.DateTimePicker date_NgayMuon_PM;
        private System.Windows.Forms.ComboBox cbMaDG_PM;
        private System.Windows.Forms.ComboBox cbTenSach_PM;
    }
}
