﻿namespace QLThuVien
{
    partial class BaoCao
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BaoCao));
            this.panel1 = new System.Windows.Forms.Panel();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.panel22 = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.TkDocGia = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.TkAdmin = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.TkMuonSach = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.TkSach = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.TKLoaiSach = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.TKTacGia = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.TKNhaXB = new System.Windows.Forms.Label();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.dgvBaoCao = new System.Windows.Forms.DataGridView();
            this.btQuaHan_BC = new System.Windows.Forms.Button();
            this.btDangMuon_BC = new System.Windows.Forms.Button();
            this.lbTong = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lbdangmuon = new System.Windows.Forms.Label();
            this.lbquahan = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.panel22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel23.SuspendLayout();
            this.panel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.panel21.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel19.SuspendLayout();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel14.SuspendLayout();
            this.panel15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.panel16.SuspendLayout();
            this.panel17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel18.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBaoCao)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.groupBox10);
            this.panel1.Controls.Add(this.groupBox9);
            this.panel1.Location = new System.Drawing.Point(12, 9);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1149, 326);
            this.panel1.TabIndex = 0;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.panel22);
            this.groupBox10.Controls.Add(this.panel20);
            this.groupBox10.Controls.Add(this.panel6);
            this.groupBox10.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.Location = new System.Drawing.Point(208, 165);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox10.Size = new System.Drawing.Size(731, 150);
            this.groupBox10.TabIndex = 58;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Thống kê Nhân viên - Độc giả - Số sách mượn";
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel22.Controls.Add(this.pictureBox6);
            this.panel22.Controls.Add(this.TkDocGia);
            this.panel22.Controls.Add(this.panel23);
            this.panel22.Location = new System.Drawing.Point(71, 43);
            this.panel22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(137, 103);
            this.panel22.TabIndex = 42;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(71, 15);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(63, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 4;
            this.pictureBox6.TabStop = false;
            // 
            // TkDocGia
            // 
            this.TkDocGia.AutoSize = true;
            this.TkDocGia.Font = new System.Drawing.Font("Calibri", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TkDocGia.ForeColor = System.Drawing.Color.White;
            this.TkDocGia.Location = new System.Drawing.Point(13, 23);
            this.TkDocGia.Name = "TkDocGia";
            this.TkDocGia.Size = new System.Drawing.Size(29, 35);
            this.TkDocGia.TabIndex = 2;
            this.TkDocGia.Text = "0";
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.DarkCyan;
            this.panel23.Controls.Add(this.label12);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel23.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel23.Location = new System.Drawing.Point(0, 71);
            this.panel23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(137, 32);
            this.panel23.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(21, 5);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(85, 24);
            this.label12.TabIndex = 2;
            this.label12.Text = "Độc Giả";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel20.Controls.Add(this.pictureBox8);
            this.panel20.Controls.Add(this.TkAdmin);
            this.panel20.Controls.Add(this.panel21);
            this.panel20.Location = new System.Drawing.Point(527, 43);
            this.panel20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(137, 103);
            this.panel20.TabIndex = 43;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(67, 15);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(63, 50);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 4;
            this.pictureBox8.TabStop = false;
            // 
            // TkAdmin
            // 
            this.TkAdmin.AutoSize = true;
            this.TkAdmin.Font = new System.Drawing.Font("Calibri", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TkAdmin.ForeColor = System.Drawing.Color.White;
            this.TkAdmin.Location = new System.Drawing.Point(25, 23);
            this.TkAdmin.Name = "TkAdmin";
            this.TkAdmin.Size = new System.Drawing.Size(29, 35);
            this.TkAdmin.TabIndex = 2;
            this.TkAdmin.Text = "0";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.DarkCyan;
            this.panel21.Controls.Add(this.label10);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel21.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel21.Location = new System.Drawing.Point(0, 71);
            this.panel21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(137, 32);
            this.panel21.TabIndex = 0;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(11, 5);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(106, 24);
            this.label10.TabIndex = 2;
            this.label10.Text = "Nhân Viên";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel6.Controls.Add(this.pictureBox7);
            this.panel6.Controls.Add(this.TkMuonSach);
            this.panel6.Controls.Add(this.panel10);
            this.panel6.Location = new System.Drawing.Point(299, 43);
            this.panel6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(139, 103);
            this.panel6.TabIndex = 47;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(72, 15);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(63, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 4;
            this.pictureBox7.TabStop = false;
            // 
            // TkMuonSach
            // 
            this.TkMuonSach.AutoSize = true;
            this.TkMuonSach.Font = new System.Drawing.Font("Calibri", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TkMuonSach.ForeColor = System.Drawing.Color.White;
            this.TkMuonSach.Location = new System.Drawing.Point(25, 18);
            this.TkMuonSach.Name = "TkMuonSach";
            this.TkMuonSach.Size = new System.Drawing.Size(29, 35);
            this.TkMuonSach.TabIndex = 2;
            this.TkMuonSach.Text = "0";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.DarkCyan;
            this.panel10.Controls.Add(this.label1);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel10.Location = new System.Drawing.Point(0, 71);
            this.panel10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(139, 32);
            this.panel10.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(4, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 24);
            this.label1.TabIndex = 3;
            this.label1.Text = "Sách Mượn";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.panel7);
            this.groupBox9.Controls.Add(this.panel13);
            this.groupBox9.Controls.Add(this.panel15);
            this.groupBox9.Controls.Add(this.panel17);
            this.groupBox9.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.Location = new System.Drawing.Point(43, 1);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox9.Size = new System.Drawing.Size(1063, 149);
            this.groupBox9.TabIndex = 57;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Thống Kê Sách";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel7.Controls.Add(this.pictureBox2);
            this.panel7.Controls.Add(this.TkSach);
            this.panel7.Controls.Add(this.panel19);
            this.panel7.Location = new System.Drawing.Point(73, 30);
            this.panel7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(139, 103);
            this.panel7.TabIndex = 45;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(72, 15);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(63, 50);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // TkSach
            // 
            this.TkSach.AutoSize = true;
            this.TkSach.Font = new System.Drawing.Font("Calibri", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TkSach.ForeColor = System.Drawing.Color.White;
            this.TkSach.Location = new System.Drawing.Point(25, 18);
            this.TkSach.Name = "TkSach";
            this.TkSach.Size = new System.Drawing.Size(29, 35);
            this.TkSach.TabIndex = 2;
            this.TkSach.Text = "0";
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.DarkCyan;
            this.panel19.Controls.Add(this.label8);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel19.Location = new System.Drawing.Point(0, 71);
            this.panel19.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(139, 32);
            this.panel19.TabIndex = 0;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(37, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 24);
            this.label8.TabIndex = 2;
            this.label8.Text = "Sách";
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel13.Controls.Add(this.pictureBox3);
            this.panel13.Controls.Add(this.TKLoaiSach);
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Location = new System.Drawing.Point(305, 30);
            this.panel13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(139, 103);
            this.panel13.TabIndex = 44;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(69, 15);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(63, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // TKLoaiSach
            // 
            this.TKLoaiSach.AutoSize = true;
            this.TKLoaiSach.Font = new System.Drawing.Font("Calibri", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TKLoaiSach.ForeColor = System.Drawing.Color.White;
            this.TKLoaiSach.Location = new System.Drawing.Point(25, 17);
            this.TKLoaiSach.Name = "TKLoaiSach";
            this.TKLoaiSach.Size = new System.Drawing.Size(29, 35);
            this.TKLoaiSach.TabIndex = 2;
            this.TKLoaiSach.Text = "0";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.DarkCyan;
            this.panel14.Controls.Add(this.label9);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel14.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel14.Location = new System.Drawing.Point(0, 71);
            this.panel14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(139, 32);
            this.panel14.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(13, 5);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(103, 24);
            this.label9.TabIndex = 2;
            this.label9.Text = "Loại Sách";
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel15.Controls.Add(this.pictureBox4);
            this.panel15.Controls.Add(this.TKTacGia);
            this.panel15.Controls.Add(this.panel16);
            this.panel15.Location = new System.Drawing.Point(539, 30);
            this.panel15.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(137, 103);
            this.panel15.TabIndex = 46;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(71, 15);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(63, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // TKTacGia
            // 
            this.TKTacGia.AutoSize = true;
            this.TKTacGia.Font = new System.Drawing.Font("Calibri", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TKTacGia.ForeColor = System.Drawing.Color.White;
            this.TKTacGia.Location = new System.Drawing.Point(25, 18);
            this.TKTacGia.Name = "TKTacGia";
            this.TKTacGia.Size = new System.Drawing.Size(29, 35);
            this.TKTacGia.TabIndex = 2;
            this.TKTacGia.Text = "0";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.DarkCyan;
            this.panel16.Controls.Add(this.label11);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel16.ForeColor = System.Drawing.SystemColors.ControlText;
            this.panel16.Location = new System.Drawing.Point(0, 71);
            this.panel16.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(137, 32);
            this.panel16.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(25, 5);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 24);
            this.label11.TabIndex = 2;
            this.label11.Text = "Tác Giả";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.LightSeaGreen;
            this.panel17.Controls.Add(this.pictureBox5);
            this.panel17.Controls.Add(this.TKNhaXB);
            this.panel17.Controls.Add(this.panel18);
            this.panel17.Location = new System.Drawing.Point(767, 30);
            this.panel17.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(136, 103);
            this.panel17.TabIndex = 48;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(72, 15);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(63, 50);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // TKNhaXB
            // 
            this.TKNhaXB.AutoSize = true;
            this.TKNhaXB.Font = new System.Drawing.Font("Calibri", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TKNhaXB.ForeColor = System.Drawing.Color.White;
            this.TKNhaXB.Location = new System.Drawing.Point(25, 18);
            this.TKNhaXB.Name = "TKNhaXB";
            this.TKNhaXB.Size = new System.Drawing.Size(29, 35);
            this.TKNhaXB.TabIndex = 2;
            this.TKNhaXB.Text = "0";
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.DarkCyan;
            this.panel18.Controls.Add(this.label13);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel18.Location = new System.Drawing.Point(0, 71);
            this.panel18.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(136, 32);
            this.panel18.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(0, 6);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(135, 22);
            this.label13.TabIndex = 2;
            this.label13.Text = "Nhà Xuất Bản";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.groupBox11);
            this.panel2.Location = new System.Drawing.Point(12, 342);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1149, 337);
            this.panel2.TabIndex = 1;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.dgvBaoCao);
            this.groupBox11.Controls.Add(this.btQuaHan_BC);
            this.groupBox11.Controls.Add(this.btDangMuon_BC);
            this.groupBox11.Controls.Add(this.lbTong);
            this.groupBox11.Controls.Add(this.label21);
            this.groupBox11.Controls.Add(this.label20);
            this.groupBox11.Controls.Add(this.lbdangmuon);
            this.groupBox11.Controls.Add(this.lbquahan);
            this.groupBox11.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.Location = new System.Drawing.Point(17, 1);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox11.Size = new System.Drawing.Size(1111, 331);
            this.groupBox11.TabIndex = 59;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Thống kê Sinh Viên Đang Mượn Sách và Quá Hạn";
            // 
            // dgvBaoCao
            // 
            this.dgvBaoCao.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvBaoCao.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBaoCao.Location = new System.Drawing.Point(0, 137);
            this.dgvBaoCao.Margin = new System.Windows.Forms.Padding(4);
            this.dgvBaoCao.Name = "dgvBaoCao";
            this.dgvBaoCao.RowHeadersWidth = 51;
            this.dgvBaoCao.Size = new System.Drawing.Size(1097, 194);
            this.dgvBaoCao.TabIndex = 63;
            this.dgvBaoCao.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBaoCao_CellContentClick);
            this.dgvBaoCao.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvBaoCao_RowEnter);
            // 
            // btQuaHan_BC
            // 
            this.btQuaHan_BC.BackColor = System.Drawing.Color.DarkCyan;
            this.btQuaHan_BC.FlatAppearance.BorderSize = 0;
            this.btQuaHan_BC.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btQuaHan_BC.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btQuaHan_BC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btQuaHan_BC.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btQuaHan_BC.ForeColor = System.Drawing.Color.White;
            this.btQuaHan_BC.Location = new System.Drawing.Point(604, 32);
            this.btQuaHan_BC.Margin = new System.Windows.Forms.Padding(4);
            this.btQuaHan_BC.Name = "btQuaHan_BC";
            this.btQuaHan_BC.Size = new System.Drawing.Size(179, 48);
            this.btQuaHan_BC.TabIndex = 62;
            this.btQuaHan_BC.Text = "QUÁ HẠN";
            this.btQuaHan_BC.UseVisualStyleBackColor = false;
            this.btQuaHan_BC.Click += new System.EventHandler(this.btQuaHan_BC_Click);
            // 
            // btDangMuon_BC
            // 
            this.btDangMuon_BC.BackColor = System.Drawing.Color.DarkCyan;
            this.btDangMuon_BC.FlatAppearance.BorderSize = 0;
            this.btDangMuon_BC.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btDangMuon_BC.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btDangMuon_BC.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDangMuon_BC.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDangMuon_BC.ForeColor = System.Drawing.Color.White;
            this.btDangMuon_BC.Location = new System.Drawing.Point(327, 32);
            this.btDangMuon_BC.Margin = new System.Windows.Forms.Padding(4);
            this.btDangMuon_BC.Name = "btDangMuon_BC";
            this.btDangMuon_BC.Size = new System.Drawing.Size(179, 48);
            this.btDangMuon_BC.TabIndex = 61;
            this.btDangMuon_BC.Text = "ĐANG MƯỢN";
            this.btDangMuon_BC.UseVisualStyleBackColor = false;
            this.btDangMuon_BC.Click += new System.EventHandler(this.btDangMuon_BC_Click);
            // 
            // lbTong
            // 
            this.lbTong.AutoSize = true;
            this.lbTong.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTong.ForeColor = System.Drawing.Color.Red;
            this.lbTong.Location = new System.Drawing.Point(905, 95);
            this.lbTong.Name = "lbTong";
            this.lbTong.Size = new System.Drawing.Size(26, 29);
            this.lbTong.TabIndex = 57;
            this.lbTong.Text = "0";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Red;
            this.label21.Location = new System.Drawing.Point(932, 95);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(67, 29);
            this.label21.TabIndex = 56;
            this.label21.Text = "Sách";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Red;
            this.label20.Location = new System.Drawing.Point(833, 95);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(82, 29);
            this.label20.TabIndex = 55;
            this.label20.Text = "Tổng: ";
            // 
            // lbdangmuon
            // 
            this.lbdangmuon.AutoSize = true;
            this.lbdangmuon.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbdangmuon.Location = new System.Drawing.Point(381, 95);
            this.lbdangmuon.Name = "lbdangmuon";
            this.lbdangmuon.Size = new System.Drawing.Size(298, 32);
            this.lbdangmuon.TabIndex = 54;
            this.lbdangmuon.Text = "Danh sách đang mượn";
            // 
            // lbquahan
            // 
            this.lbquahan.AutoSize = true;
            this.lbquahan.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbquahan.Location = new System.Drawing.Point(381, 95);
            this.lbquahan.Name = "lbquahan";
            this.lbquahan.Size = new System.Drawing.Size(259, 32);
            this.lbquahan.TabIndex = 53;
            this.lbquahan.Text = "Danh sách quá hạn";
            // 
            // BaoCao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "BaoCao";
            this.Size = new System.Drawing.Size(1173, 695);
            this.Load += new System.EventHandler(this.BaoCao_Load);
            this.panel1.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBaoCao)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label TkDocGia;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label TkAdmin;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label TkMuonSach;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label TkSach;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label TKLoaiSach;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label TKTacGia;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label TKNhaXB;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label lbTong;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lbdangmuon;
        private System.Windows.Forms.Label lbquahan;
        private System.Windows.Forms.DataGridView dgvBaoCao;
        private System.Windows.Forms.Button btQuaHan_BC;
        private System.Windows.Forms.Button btDangMuon_BC;
    }
}
