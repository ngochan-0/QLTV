﻿namespace QLThuVien
{
    partial class QLDocGia
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbGioiTinh_QLDG = new System.Windows.Forms.ComboBox();
            this.btHuy_QLDG = new System.Windows.Forms.Button();
            this.btCapNhat_QLDG = new System.Windows.Forms.Button();
            this.btXoa_QLDG = new System.Windows.Forms.Button();
            this.btSua_QLDG = new System.Windows.Forms.Button();
            this.btThem_QLDG = new System.Windows.Forms.Button();
            this.txtSDT_QLDG = new System.Windows.Forms.TextBox();
            this.txtDiaChi_QLDG = new System.Windows.Forms.TextBox();
            this.txtTenDG_QLDG = new System.Windows.Forms.TextBox();
            this.txtMaDG_QLDG = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtTimKiemDocGia = new System.Windows.Forms.TextBox();
            this.rbTenDG_QLDG = new System.Windows.Forms.RadioButton();
            this.rbMaDG_QLDG = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgvDocGia = new System.Windows.Forms.DataGridView();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocGia)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.cbGioiTinh_QLDG);
            this.panel1.Controls.Add(this.btHuy_QLDG);
            this.panel1.Controls.Add(this.btCapNhat_QLDG);
            this.panel1.Controls.Add(this.btXoa_QLDG);
            this.panel1.Controls.Add(this.btSua_QLDG);
            this.panel1.Controls.Add(this.btThem_QLDG);
            this.panel1.Controls.Add(this.txtSDT_QLDG);
            this.panel1.Controls.Add(this.txtDiaChi_QLDG);
            this.panel1.Controls.Add(this.txtTenDG_QLDG);
            this.panel1.Controls.Add(this.txtMaDG_QLDG);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Location = new System.Drawing.Point(16, 18);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(490, 657);
            this.panel1.TabIndex = 0;
            // 
            // cbGioiTinh_QLDG
            // 
            this.cbGioiTinh_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbGioiTinh_QLDG.FormattingEnabled = true;
            this.cbGioiTinh_QLDG.Items.AddRange(new object[] {
            "Nam",
            "Nữ"});
            this.cbGioiTinh_QLDG.Location = new System.Drawing.Point(208, 309);
            this.cbGioiTinh_QLDG.Margin = new System.Windows.Forms.Padding(4);
            this.cbGioiTinh_QLDG.Name = "cbGioiTinh_QLDG";
            this.cbGioiTinh_QLDG.Size = new System.Drawing.Size(257, 33);
            this.cbGioiTinh_QLDG.TabIndex = 64;
            // 
            // btHuy_QLDG
            // 
            this.btHuy_QLDG.BackColor = System.Drawing.Color.DarkCyan;
            this.btHuy_QLDG.FlatAppearance.BorderSize = 0;
            this.btHuy_QLDG.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_QLDG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_QLDG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btHuy_QLDG.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btHuy_QLDG.ForeColor = System.Drawing.Color.White;
            this.btHuy_QLDG.Location = new System.Drawing.Point(267, 571);
            this.btHuy_QLDG.Margin = new System.Windows.Forms.Padding(4);
            this.btHuy_QLDG.Name = "btHuy_QLDG";
            this.btHuy_QLDG.Size = new System.Drawing.Size(128, 41);
            this.btHuy_QLDG.TabIndex = 63;
            this.btHuy_QLDG.Text = "HỦY";
            this.btHuy_QLDG.UseVisualStyleBackColor = false;
            this.btHuy_QLDG.Click += new System.EventHandler(this.btHuy_QLDG_Click);
            // 
            // btCapNhat_QLDG
            // 
            this.btCapNhat_QLDG.BackColor = System.Drawing.Color.DarkCyan;
            this.btCapNhat_QLDG.FlatAppearance.BorderSize = 0;
            this.btCapNhat_QLDG.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_QLDG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_QLDG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCapNhat_QLDG.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCapNhat_QLDG.ForeColor = System.Drawing.Color.White;
            this.btCapNhat_QLDG.Location = new System.Drawing.Point(95, 571);
            this.btCapNhat_QLDG.Margin = new System.Windows.Forms.Padding(4);
            this.btCapNhat_QLDG.Name = "btCapNhat_QLDG";
            this.btCapNhat_QLDG.Size = new System.Drawing.Size(128, 41);
            this.btCapNhat_QLDG.TabIndex = 62;
            this.btCapNhat_QLDG.Text = "CẬP NHẬT";
            this.btCapNhat_QLDG.UseVisualStyleBackColor = false;
            this.btCapNhat_QLDG.Click += new System.EventHandler(this.btCapNhat_QLDG_Click);
            // 
            // btXoa_QLDG
            // 
            this.btXoa_QLDG.BackColor = System.Drawing.Color.DarkCyan;
            this.btXoa_QLDG.FlatAppearance.BorderSize = 0;
            this.btXoa_QLDG.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btXoa_QLDG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btXoa_QLDG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btXoa_QLDG.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoa_QLDG.ForeColor = System.Drawing.Color.White;
            this.btXoa_QLDG.Location = new System.Drawing.Point(347, 497);
            this.btXoa_QLDG.Margin = new System.Windows.Forms.Padding(4);
            this.btXoa_QLDG.Name = "btXoa_QLDG";
            this.btXoa_QLDG.Size = new System.Drawing.Size(128, 41);
            this.btXoa_QLDG.TabIndex = 61;
            this.btXoa_QLDG.Text = "XÓA";
            this.btXoa_QLDG.UseVisualStyleBackColor = false;
            this.btXoa_QLDG.Click += new System.EventHandler(this.btXoa_QLDG_Click);
            // 
            // btSua_QLDG
            // 
            this.btSua_QLDG.BackColor = System.Drawing.Color.DarkCyan;
            this.btSua_QLDG.FlatAppearance.BorderSize = 0;
            this.btSua_QLDG.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btSua_QLDG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btSua_QLDG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSua_QLDG.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSua_QLDG.ForeColor = System.Drawing.Color.White;
            this.btSua_QLDG.Location = new System.Drawing.Point(180, 497);
            this.btSua_QLDG.Margin = new System.Windows.Forms.Padding(4);
            this.btSua_QLDG.Name = "btSua_QLDG";
            this.btSua_QLDG.Size = new System.Drawing.Size(128, 41);
            this.btSua_QLDG.TabIndex = 60;
            this.btSua_QLDG.Text = "SỬA";
            this.btSua_QLDG.UseVisualStyleBackColor = false;
            this.btSua_QLDG.Click += new System.EventHandler(this.btSua_QLDG_Click);
            // 
            // btThem_QLDG
            // 
            this.btThem_QLDG.BackColor = System.Drawing.Color.DarkCyan;
            this.btThem_QLDG.FlatAppearance.BorderSize = 0;
            this.btThem_QLDG.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btThem_QLDG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btThem_QLDG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btThem_QLDG.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThem_QLDG.ForeColor = System.Drawing.Color.White;
            this.btThem_QLDG.Location = new System.Drawing.Point(13, 497);
            this.btThem_QLDG.Margin = new System.Windows.Forms.Padding(4);
            this.btThem_QLDG.Name = "btThem_QLDG";
            this.btThem_QLDG.Size = new System.Drawing.Size(128, 41);
            this.btThem_QLDG.TabIndex = 59;
            this.btThem_QLDG.Text = "THÊM";
            this.btThem_QLDG.UseVisualStyleBackColor = false;
            this.btThem_QLDG.Click += new System.EventHandler(this.btThem_QLDG_Click);
            // 
            // txtSDT_QLDG
            // 
            this.txtSDT_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDT_QLDG.Location = new System.Drawing.Point(208, 425);
            this.txtSDT_QLDG.Margin = new System.Windows.Forms.Padding(4);
            this.txtSDT_QLDG.Name = "txtSDT_QLDG";
            this.txtSDT_QLDG.Size = new System.Drawing.Size(257, 30);
            this.txtSDT_QLDG.TabIndex = 57;
            // 
            // txtDiaChi_QLDG
            // 
            this.txtDiaChi_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiaChi_QLDG.Location = new System.Drawing.Point(210, 367);
            this.txtDiaChi_QLDG.Margin = new System.Windows.Forms.Padding(4);
            this.txtDiaChi_QLDG.Name = "txtDiaChi_QLDG";
            this.txtDiaChi_QLDG.Size = new System.Drawing.Size(257, 30);
            this.txtDiaChi_QLDG.TabIndex = 56;
            // 
            // txtTenDG_QLDG
            // 
            this.txtTenDG_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDG_QLDG.Location = new System.Drawing.Point(208, 252);
            this.txtTenDG_QLDG.Margin = new System.Windows.Forms.Padding(4);
            this.txtTenDG_QLDG.Name = "txtTenDG_QLDG";
            this.txtTenDG_QLDG.Size = new System.Drawing.Size(257, 30);
            this.txtTenDG_QLDG.TabIndex = 54;
            // 
            // txtMaDG_QLDG
            // 
            this.txtMaDG_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaDG_QLDG.Location = new System.Drawing.Point(208, 193);
            this.txtMaDG_QLDG.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaDG_QLDG.Name = "txtMaDG_QLDG";
            this.txtMaDG_QLDG.Size = new System.Drawing.Size(257, 30);
            this.txtMaDG_QLDG.TabIndex = 53;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(24, 425);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(140, 28);
            this.label7.TabIndex = 51;
            this.label7.Text = "Số điện thoại:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(24, 367);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 28);
            this.label6.TabIndex = 50;
            this.label6.Text = "Địa chỉ:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(24, 309);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 28);
            this.label5.TabIndex = 49;
            this.label5.Text = "Giới tính:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(24, 251);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 28);
            this.label4.TabIndex = 48;
            this.label4.Text = "Họ và tên:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(24, 193);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 28);
            this.label3.TabIndex = 47;
            this.label3.Text = "Mã độc giả:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtTimKiemDocGia);
            this.groupBox2.Controls.Add(this.rbTenDG_QLDG);
            this.groupBox2.Controls.Add(this.rbMaDG_QLDG);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(19, 22);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(448, 135);
            this.groupBox2.TabIndex = 46;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tìm Kiếm Độc Giả";
            // 
            // txtTimKiemDocGia
            // 
            this.txtTimKiemDocGia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimKiemDocGia.Location = new System.Drawing.Point(25, 91);
            this.txtTimKiemDocGia.Margin = new System.Windows.Forms.Padding(4);
            this.txtTimKiemDocGia.Name = "txtTimKiemDocGia";
            this.txtTimKiemDocGia.Size = new System.Drawing.Size(396, 30);
            this.txtTimKiemDocGia.TabIndex = 55;
            this.txtTimKiemDocGia.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtTimKiemDocGia_KeyUp);
            // 
            // rbTenDG_QLDG
            // 
            this.rbTenDG_QLDG.AutoSize = true;
            this.rbTenDG_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbTenDG_QLDG.Location = new System.Drawing.Point(279, 42);
            this.rbTenDG_QLDG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbTenDG_QLDG.Name = "rbTenDG_QLDG";
            this.rbTenDG_QLDG.Size = new System.Drawing.Size(145, 30);
            this.rbTenDG_QLDG.TabIndex = 1;
            this.rbTenDG_QLDG.TabStop = true;
            this.rbTenDG_QLDG.Text = "Tên độc giả";
            this.rbTenDG_QLDG.UseVisualStyleBackColor = true;
            // 
            // rbMaDG_QLDG
            // 
            this.rbMaDG_QLDG.AutoSize = true;
            this.rbMaDG_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbMaDG_QLDG.Location = new System.Drawing.Point(25, 42);
            this.rbMaDG_QLDG.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rbMaDG_QLDG.Name = "rbMaDG_QLDG";
            this.rbMaDG_QLDG.Size = new System.Drawing.Size(139, 30);
            this.rbMaDG_QLDG.TabIndex = 0;
            this.rbMaDG_QLDG.TabStop = true;
            this.rbMaDG_QLDG.Text = "Mã độc giả";
            this.rbMaDG_QLDG.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.dgvDocGia);
            this.panel2.Location = new System.Drawing.Point(535, 18);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(611, 657);
            this.panel2.TabIndex = 1;
            // 
            // dgvDocGia
            // 
            this.dgvDocGia.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDocGia.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDocGia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDocGia.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvDocGia.Location = new System.Drawing.Point(24, 22);
            this.dgvDocGia.Margin = new System.Windows.Forms.Padding(4);
            this.dgvDocGia.Name = "dgvDocGia";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvDocGia.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvDocGia.RowHeadersWidth = 51;
            this.dgvDocGia.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDocGia.Size = new System.Drawing.Size(563, 612);
            this.dgvDocGia.TabIndex = 0;
            this.dgvDocGia.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDocGia_RowEnter);
            // 
            // QLDocGia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "QLDocGia";
            this.Size = new System.Drawing.Size(1173, 695);
            this.Load += new System.EventHandler(this.QLDocGia_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocGia)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbTenDG_QLDG;
        private System.Windows.Forms.RadioButton rbMaDG_QLDG;
        private System.Windows.Forms.DataGridView dgvDocGia;
        private System.Windows.Forms.TextBox txtTimKiemDocGia;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMaDG_QLDG;
        private System.Windows.Forms.TextBox txtSDT_QLDG;
        private System.Windows.Forms.TextBox txtDiaChi_QLDG;
        private System.Windows.Forms.TextBox txtTenDG_QLDG;
        private System.Windows.Forms.Button btHuy_QLDG;
        private System.Windows.Forms.Button btCapNhat_QLDG;
        private System.Windows.Forms.Button btXoa_QLDG;
        private System.Windows.Forms.Button btSua_QLDG;
        private System.Windows.Forms.Button btThem_QLDG;
        private System.Windows.Forms.ComboBox cbGioiTinh_QLDG;
    }
}
