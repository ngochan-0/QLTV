﻿namespace QLThuVien
{
    partial class Sach
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cbLoaiSach_Sach = new System.Windows.Forms.ComboBox();
            this.cbNXB_Sach = new System.Windows.Forms.ComboBox();
            this.cbTacGia_Sach = new System.Windows.Forms.ComboBox();
            this.btTrangChu_Sach = new System.Windows.Forms.Button();
            this.btHuy_Sach = new System.Windows.Forms.Button();
            this.btCapNhat_Sach = new System.Windows.Forms.Button();
            this.btXoa_Sach = new System.Windows.Forms.Button();
            this.btSua_Sach = new System.Windows.Forms.Button();
            this.btThem_Sach = new System.Windows.Forms.Button();
            this.txtSoLuong_Sach = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtGiaBan_Sach = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSoTrang_Sach = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTenSach_Sach = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMaSach_Sach = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dgvTimKiem_Sach = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtTimKiem_Sach = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimKiem_Sach)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1152, 51);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1150, 49);
            this.label1.TabIndex = 0;
            this.label1.Text = "SÁCH";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.cbLoaiSach_Sach);
            this.panel2.Controls.Add(this.cbNXB_Sach);
            this.panel2.Controls.Add(this.cbTacGia_Sach);
            this.panel2.Controls.Add(this.btTrangChu_Sach);
            this.panel2.Controls.Add(this.btHuy_Sach);
            this.panel2.Controls.Add(this.btCapNhat_Sach);
            this.panel2.Controls.Add(this.btXoa_Sach);
            this.panel2.Controls.Add(this.btSua_Sach);
            this.panel2.Controls.Add(this.btThem_Sach);
            this.panel2.Controls.Add(this.txtSoLuong_Sach);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.txtGiaBan_Sach);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.txtSoTrang_Sach);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.txtTenSach_Sach);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtMaSach_Sach);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(16, 69);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(499, 563);
            this.panel2.TabIndex = 1;
            // 
            // cbLoaiSach_Sach
            // 
            this.cbLoaiSach_Sach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbLoaiSach_Sach.FormattingEnabled = true;
            this.cbLoaiSach_Sach.Location = new System.Drawing.Point(171, 226);
            this.cbLoaiSach_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbLoaiSach_Sach.Name = "cbLoaiSach_Sach";
            this.cbLoaiSach_Sach.Size = new System.Drawing.Size(296, 33);
            this.cbLoaiSach_Sach.TabIndex = 81;
            // 
            // cbNXB_Sach
            // 
            this.cbNXB_Sach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbNXB_Sach.FormattingEnabled = true;
            this.cbNXB_Sach.Location = new System.Drawing.Point(171, 172);
            this.cbNXB_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbNXB_Sach.Name = "cbNXB_Sach";
            this.cbNXB_Sach.Size = new System.Drawing.Size(296, 33);
            this.cbNXB_Sach.TabIndex = 80;
            // 
            // cbTacGia_Sach
            // 
            this.cbTacGia_Sach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbTacGia_Sach.FormattingEnabled = true;
            this.cbTacGia_Sach.Location = new System.Drawing.Point(171, 117);
            this.cbTacGia_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbTacGia_Sach.Name = "cbTacGia_Sach";
            this.cbTacGia_Sach.Size = new System.Drawing.Size(296, 33);
            this.cbTacGia_Sach.TabIndex = 79;
            // 
            // btTrangChu_Sach
            // 
            this.btTrangChu_Sach.BackColor = System.Drawing.Color.DarkCyan;
            this.btTrangChu_Sach.FlatAppearance.BorderSize = 0;
            this.btTrangChu_Sach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btTrangChu_Sach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btTrangChu_Sach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btTrangChu_Sach.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTrangChu_Sach.ForeColor = System.Drawing.Color.White;
            this.btTrangChu_Sach.Location = new System.Drawing.Point(327, 495);
            this.btTrangChu_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btTrangChu_Sach.Name = "btTrangChu_Sach";
            this.btTrangChu_Sach.Size = new System.Drawing.Size(145, 41);
            this.btTrangChu_Sach.TabIndex = 78;
            this.btTrangChu_Sach.Text = "TRANG CHỦ";
            this.btTrangChu_Sach.UseVisualStyleBackColor = false;
            this.btTrangChu_Sach.Click += new System.EventHandler(this.btTrangChu_Sach_Click);
            // 
            // btHuy_Sach
            // 
            this.btHuy_Sach.BackColor = System.Drawing.Color.DarkCyan;
            this.btHuy_Sach.FlatAppearance.BorderSize = 0;
            this.btHuy_Sach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_Sach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_Sach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btHuy_Sach.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btHuy_Sach.ForeColor = System.Drawing.Color.White;
            this.btHuy_Sach.Location = new System.Drawing.Point(175, 495);
            this.btHuy_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btHuy_Sach.Name = "btHuy_Sach";
            this.btHuy_Sach.Size = new System.Drawing.Size(145, 41);
            this.btHuy_Sach.TabIndex = 77;
            this.btHuy_Sach.Text = "HỦY";
            this.btHuy_Sach.UseVisualStyleBackColor = false;
            this.btHuy_Sach.Click += new System.EventHandler(this.btHuy_Sach_Click);
            // 
            // btCapNhat_Sach
            // 
            this.btCapNhat_Sach.BackColor = System.Drawing.Color.DarkCyan;
            this.btCapNhat_Sach.FlatAppearance.BorderSize = 0;
            this.btCapNhat_Sach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_Sach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_Sach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCapNhat_Sach.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCapNhat_Sach.ForeColor = System.Drawing.Color.White;
            this.btCapNhat_Sach.Location = new System.Drawing.Point(24, 495);
            this.btCapNhat_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btCapNhat_Sach.Name = "btCapNhat_Sach";
            this.btCapNhat_Sach.Size = new System.Drawing.Size(145, 41);
            this.btCapNhat_Sach.TabIndex = 76;
            this.btCapNhat_Sach.Text = "CẬP NHẬT";
            this.btCapNhat_Sach.UseVisualStyleBackColor = false;
            this.btCapNhat_Sach.Click += new System.EventHandler(this.btCapNhat_Sach_Click);
            // 
            // btXoa_Sach
            // 
            this.btXoa_Sach.BackColor = System.Drawing.Color.DarkCyan;
            this.btXoa_Sach.FlatAppearance.BorderSize = 0;
            this.btXoa_Sach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btXoa_Sach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btXoa_Sach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btXoa_Sach.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoa_Sach.ForeColor = System.Drawing.Color.White;
            this.btXoa_Sach.Location = new System.Drawing.Point(327, 434);
            this.btXoa_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btXoa_Sach.Name = "btXoa_Sach";
            this.btXoa_Sach.Size = new System.Drawing.Size(145, 41);
            this.btXoa_Sach.TabIndex = 75;
            this.btXoa_Sach.Text = "XÓA";
            this.btXoa_Sach.UseVisualStyleBackColor = false;
            this.btXoa_Sach.Click += new System.EventHandler(this.btXoa_Sach_Click);
            // 
            // btSua_Sach
            // 
            this.btSua_Sach.BackColor = System.Drawing.Color.DarkCyan;
            this.btSua_Sach.FlatAppearance.BorderSize = 0;
            this.btSua_Sach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btSua_Sach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btSua_Sach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSua_Sach.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSua_Sach.ForeColor = System.Drawing.Color.White;
            this.btSua_Sach.Location = new System.Drawing.Point(175, 434);
            this.btSua_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btSua_Sach.Name = "btSua_Sach";
            this.btSua_Sach.Size = new System.Drawing.Size(145, 41);
            this.btSua_Sach.TabIndex = 74;
            this.btSua_Sach.Text = "SỬA";
            this.btSua_Sach.UseVisualStyleBackColor = false;
            this.btSua_Sach.Click += new System.EventHandler(this.btSua_Sach_Click);
            // 
            // btThem_Sach
            // 
            this.btThem_Sach.BackColor = System.Drawing.Color.DarkCyan;
            this.btThem_Sach.FlatAppearance.BorderSize = 0;
            this.btThem_Sach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btThem_Sach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btThem_Sach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btThem_Sach.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThem_Sach.ForeColor = System.Drawing.Color.White;
            this.btThem_Sach.Location = new System.Drawing.Point(24, 434);
            this.btThem_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btThem_Sach.Name = "btThem_Sach";
            this.btThem_Sach.Size = new System.Drawing.Size(145, 41);
            this.btThem_Sach.TabIndex = 73;
            this.btThem_Sach.Text = "THÊM";
            this.btThem_Sach.UseVisualStyleBackColor = false;
            this.btThem_Sach.Click += new System.EventHandler(this.btThem_Sach_Click);
            // 
            // txtSoLuong_Sach
            // 
            this.txtSoLuong_Sach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoLuong_Sach.Location = new System.Drawing.Point(171, 385);
            this.txtSoLuong_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSoLuong_Sach.Name = "txtSoLuong_Sach";
            this.txtSoLuong_Sach.Size = new System.Drawing.Size(296, 30);
            this.txtSoLuong_Sach.TabIndex = 72;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(3, 382);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 25);
            this.label6.TabIndex = 71;
            this.label6.Text = "Số lượng:";
            // 
            // txtGiaBan_Sach
            // 
            this.txtGiaBan_Sach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGiaBan_Sach.Location = new System.Drawing.Point(171, 332);
            this.txtGiaBan_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtGiaBan_Sach.Name = "txtGiaBan_Sach";
            this.txtGiaBan_Sach.Size = new System.Drawing.Size(296, 30);
            this.txtGiaBan_Sach.TabIndex = 70;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(3, 329);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 25);
            this.label7.TabIndex = 69;
            this.label7.Text = "Giá bán:";
            // 
            // txtSoTrang_Sach
            // 
            this.txtSoTrang_Sach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoTrang_Sach.Location = new System.Drawing.Point(171, 279);
            this.txtSoTrang_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSoTrang_Sach.Name = "txtSoTrang_Sach";
            this.txtSoTrang_Sach.Size = new System.Drawing.Size(296, 30);
            this.txtSoTrang_Sach.TabIndex = 68;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(3, 276);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 25);
            this.label8.TabIndex = 67;
            this.label8.Text = "Số trang:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(3, 223);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(102, 25);
            this.label9.TabIndex = 65;
            this.label9.Text = "Loại sách:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(3, 170);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(134, 25);
            this.label5.TabIndex = 63;
            this.label5.Text = "Nhà xuất bản:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(3, 117);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 25);
            this.label4.TabIndex = 61;
            this.label4.Text = "Tác giả:";
            // 
            // txtTenSach_Sach
            // 
            this.txtTenSach_Sach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenSach_Sach.Location = new System.Drawing.Point(171, 68);
            this.txtTenSach_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTenSach_Sach.Name = "txtTenSach_Sach";
            this.txtTenSach_Sach.Size = new System.Drawing.Size(296, 30);
            this.txtTenSach_Sach.TabIndex = 60;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(3, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 25);
            this.label3.TabIndex = 59;
            this.label3.Text = "Tên sách:";
            // 
            // txtMaSach_Sach
            // 
            this.txtMaSach_Sach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaSach_Sach.Location = new System.Drawing.Point(171, 11);
            this.txtMaSach_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMaSach_Sach.Name = "txtMaSach_Sach";
            this.txtMaSach_Sach.Size = new System.Drawing.Size(296, 30);
            this.txtMaSach_Sach.TabIndex = 58;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(3, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(93, 25);
            this.label2.TabIndex = 57;
            this.label2.Text = "Mã sách:";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.dgvTimKiem_Sach);
            this.panel3.Controls.Add(this.groupBox1);
            this.panel3.Location = new System.Drawing.Point(540, 69);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(595, 563);
            this.panel3.TabIndex = 2;
            // 
            // dgvTimKiem_Sach
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvTimKiem_Sach.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTimKiem_Sach.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTimKiem_Sach.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTimKiem_Sach.Location = new System.Drawing.Point(19, 117);
            this.dgvTimKiem_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dgvTimKiem_Sach.Name = "dgvTimKiem_Sach";
            this.dgvTimKiem_Sach.RowHeadersWidth = 51;
            this.dgvTimKiem_Sach.Size = new System.Drawing.Size(555, 418);
            this.dgvTimKiem_Sach.TabIndex = 86;
            this.dgvTimKiem_Sach.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTimKiem_Sach_RowEnter);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtTimKiem_Sach);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(19, 11);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.groupBox1.Size = new System.Drawing.Size(555, 81);
            this.groupBox1.TabIndex = 85;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm Kiếm";
            // 
            // txtTimKiem_Sach
            // 
            this.txtTimKiem_Sach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimKiem_Sach.Location = new System.Drawing.Point(24, 36);
            this.txtTimKiem_Sach.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTimKiem_Sach.Name = "txtTimKiem_Sach";
            this.txtTimKiem_Sach.Size = new System.Drawing.Size(508, 30);
            this.txtTimKiem_Sach.TabIndex = 86;
            this.txtTimKiem_Sach.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtTimKiem_Sach_KeyUp);
            // 
            // Sach
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1152, 647);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Sach";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sach";
            this.Load += new System.EventHandler(this.Sach_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimKiem_Sach)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSoLuong_Sach;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtGiaBan_Sach;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtSoTrang_Sach;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTenSach_Sach;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMaSach_Sach;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbLoaiSach_Sach;
        private System.Windows.Forms.ComboBox cbNXB_Sach;
        private System.Windows.Forms.ComboBox cbTacGia_Sach;
        private System.Windows.Forms.Button btTrangChu_Sach;
        private System.Windows.Forms.Button btHuy_Sach;
        private System.Windows.Forms.Button btCapNhat_Sach;
        private System.Windows.Forms.Button btXoa_Sach;
        private System.Windows.Forms.Button btSua_Sach;
        private System.Windows.Forms.Button btThem_Sach;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView dgvTimKiem_Sach;
        private System.Windows.Forms.TextBox txtTimKiem_Sach;
    }
}