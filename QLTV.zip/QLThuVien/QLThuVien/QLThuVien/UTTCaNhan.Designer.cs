﻿namespace QLThuVien
{
    partial class UTTCaNhan
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbGioiTinh_TTCN = new System.Windows.Forms.ComboBox();
            this.btHuy_TTCN = new System.Windows.Forms.Button();
            this.btCapNhat_TTCN = new System.Windows.Forms.Button();
            this.btDoiMK_TTCN = new System.Windows.Forms.Button();
            this.txtMatKhau_TTCN = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSDT_TTCN = new System.Windows.Forms.TextBox();
            this.txtDiaChi_TTCN = new System.Windows.Forms.TextBox();
            this.txtTenDG_TTCN = new System.Windows.Forms.TextBox();
            this.txtMaDG_TTCN = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtEmail_TTCN = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txtEmail_TTCN);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.cbGioiTinh_TTCN);
            this.panel1.Controls.Add(this.btHuy_TTCN);
            this.panel1.Controls.Add(this.btCapNhat_TTCN);
            this.panel1.Controls.Add(this.btDoiMK_TTCN);
            this.panel1.Controls.Add(this.txtMatKhau_TTCN);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtSDT_TTCN);
            this.panel1.Controls.Add(this.txtDiaChi_TTCN);
            this.panel1.Controls.Add(this.txtTenDG_TTCN);
            this.panel1.Controls.Add(this.txtMaDG_TTCN);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(16, 17);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(833, 492);
            this.panel1.TabIndex = 5;
            // 
            // cbGioiTinh_TTCN
            // 
            this.cbGioiTinh_TTCN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbGioiTinh_TTCN.FormattingEnabled = true;
            this.cbGioiTinh_TTCN.Items.AddRange(new object[] {
            "Nữ ",
            "Nam"});
            this.cbGioiTinh_TTCN.Location = new System.Drawing.Point(497, 165);
            this.cbGioiTinh_TTCN.Name = "cbGioiTinh_TTCN";
            this.cbGioiTinh_TTCN.Size = new System.Drawing.Size(240, 28);
            this.cbGioiTinh_TTCN.TabIndex = 80;
            // 
            // btHuy_TTCN
            // 
            this.btHuy_TTCN.BackColor = System.Drawing.Color.DarkCyan;
            this.btHuy_TTCN.FlatAppearance.BorderSize = 0;
            this.btHuy_TTCN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_TTCN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_TTCN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btHuy_TTCN.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btHuy_TTCN.ForeColor = System.Drawing.Color.White;
            this.btHuy_TTCN.Location = new System.Drawing.Point(340, 416);
            this.btHuy_TTCN.Name = "btHuy_TTCN";
            this.btHuy_TTCN.Size = new System.Drawing.Size(153, 39);
            this.btHuy_TTCN.TabIndex = 79;
            this.btHuy_TTCN.Text = "HỦY";
            this.btHuy_TTCN.UseVisualStyleBackColor = false;
            this.btHuy_TTCN.Click += new System.EventHandler(this.btHuy_TTCN_Click);
            // 
            // btCapNhat_TTCN
            // 
            this.btCapNhat_TTCN.BackColor = System.Drawing.Color.DarkCyan;
            this.btCapNhat_TTCN.FlatAppearance.BorderSize = 0;
            this.btCapNhat_TTCN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_TTCN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_TTCN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCapNhat_TTCN.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCapNhat_TTCN.ForeColor = System.Drawing.Color.White;
            this.btCapNhat_TTCN.Location = new System.Drawing.Point(584, 416);
            this.btCapNhat_TTCN.Name = "btCapNhat_TTCN";
            this.btCapNhat_TTCN.Size = new System.Drawing.Size(153, 39);
            this.btCapNhat_TTCN.TabIndex = 78;
            this.btCapNhat_TTCN.Text = "CẬP NHẬT";
            this.btCapNhat_TTCN.UseVisualStyleBackColor = false;
            this.btCapNhat_TTCN.Click += new System.EventHandler(this.btCapNhat_TTCN_Click);
            // 
            // btDoiMK_TTCN
            // 
            this.btDoiMK_TTCN.BackColor = System.Drawing.Color.DarkCyan;
            this.btDoiMK_TTCN.FlatAppearance.BorderSize = 0;
            this.btDoiMK_TTCN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btDoiMK_TTCN.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btDoiMK_TTCN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDoiMK_TTCN.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDoiMK_TTCN.ForeColor = System.Drawing.Color.White;
            this.btDoiMK_TTCN.Location = new System.Drawing.Point(111, 416);
            this.btDoiMK_TTCN.Name = "btDoiMK_TTCN";
            this.btDoiMK_TTCN.Size = new System.Drawing.Size(153, 39);
            this.btDoiMK_TTCN.TabIndex = 77;
            this.btDoiMK_TTCN.Text = "SỬA";
            this.btDoiMK_TTCN.UseVisualStyleBackColor = false;
            this.btDoiMK_TTCN.Click += new System.EventHandler(this.btDoiMK_TTCN_Click);
            // 
            // txtMatKhau_TTCN
            // 
            this.txtMatKhau_TTCN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatKhau_TTCN.Location = new System.Drawing.Point(497, 299);
            this.txtMatKhau_TTCN.Name = "txtMatKhau_TTCN";
            this.txtMatKhau_TTCN.Size = new System.Drawing.Size(240, 26);
            this.txtMatKhau_TTCN.TabIndex = 76;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(334, 297);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 26);
            this.label1.TabIndex = 75;
            this.label1.Text = "Mật khẩu:";
            // 
            // txtSDT_TTCN
            // 
            this.txtSDT_TTCN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDT_TTCN.Location = new System.Drawing.Point(497, 255);
            this.txtSDT_TTCN.Name = "txtSDT_TTCN";
            this.txtSDT_TTCN.Size = new System.Drawing.Size(240, 26);
            this.txtSDT_TTCN.TabIndex = 73;
            // 
            // txtDiaChi_TTCN
            // 
            this.txtDiaChi_TTCN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiaChi_TTCN.Location = new System.Drawing.Point(497, 211);
            this.txtDiaChi_TTCN.Name = "txtDiaChi_TTCN";
            this.txtDiaChi_TTCN.Size = new System.Drawing.Size(240, 26);
            this.txtDiaChi_TTCN.TabIndex = 72;
            // 
            // txtTenDG_TTCN
            // 
            this.txtTenDG_TTCN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDG_TTCN.Location = new System.Drawing.Point(497, 121);
            this.txtTenDG_TTCN.Name = "txtTenDG_TTCN";
            this.txtTenDG_TTCN.Size = new System.Drawing.Size(240, 26);
            this.txtTenDG_TTCN.TabIndex = 71;
            // 
            // txtMaDG_TTCN
            // 
            this.txtMaDG_TTCN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaDG_TTCN.Location = new System.Drawing.Point(497, 77);
            this.txtMaDG_TTCN.Name = "txtMaDG_TTCN";
            this.txtMaDG_TTCN.Size = new System.Drawing.Size(240, 26);
            this.txtMaDG_TTCN.TabIndex = 70;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(334, 253);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 26);
            this.label7.TabIndex = 69;
            this.label7.Text = "Số điện thoại:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(334, 209);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(76, 26);
            this.label6.TabIndex = 68;
            this.label6.Text = "Địa chỉ:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(334, 165);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 26);
            this.label5.TabIndex = 67;
            this.label5.Text = "Giới tính:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(334, 121);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 26);
            this.label4.TabIndex = 66;
            this.label4.Text = "Họ và tên:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(334, 77);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 26);
            this.label3.TabIndex = 65;
            this.label3.Text = "Mã độc giả:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::QLThuVien.Properties.Resources.user;
            this.pictureBox1.Location = new System.Drawing.Point(37, 89);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(243, 269);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // txtEmail_TTCN
            // 
            this.txtEmail_TTCN.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail_TTCN.Location = new System.Drawing.Point(497, 343);
            this.txtEmail_TTCN.Name = "txtEmail_TTCN";
            this.txtEmail_TTCN.Size = new System.Drawing.Size(240, 26);
            this.txtEmail_TTCN.TabIndex = 82;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(334, 341);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 26);
            this.label2.TabIndex = 81;
            this.label2.Text = "Email:";
            // 
            // UTTCaNhan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "UTTCaNhan";
            this.Size = new System.Drawing.Size(864, 526);
            this.Load += new System.EventHandler(this.UTTCaNhan_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtSDT_TTCN;
        private System.Windows.Forms.TextBox txtDiaChi_TTCN;
        private System.Windows.Forms.TextBox txtTenDG_TTCN;
        private System.Windows.Forms.TextBox txtMaDG_TTCN;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMatKhau_TTCN;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btCapNhat_TTCN;
        private System.Windows.Forms.Button btDoiMK_TTCN;
        private System.Windows.Forms.Button btHuy_TTCN;
        private System.Windows.Forms.ComboBox cbGioiTinh_TTCN;
        private System.Windows.Forms.TextBox txtEmail_TTCN;
        private System.Windows.Forms.Label label2;
    }
}
