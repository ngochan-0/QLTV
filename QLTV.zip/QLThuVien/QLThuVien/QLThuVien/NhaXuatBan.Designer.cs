﻿namespace QLThuVien
{
    partial class NhaXuatBan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dgvTimKiem_NXB = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btTrangChu_NXB = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtTimKiem_NXB = new System.Windows.Forms.TextBox();
            this.btHuy_NXB = new System.Windows.Forms.Button();
            this.btCapNhat_NXB = new System.Windows.Forms.Button();
            this.btXoa_NXB = new System.Windows.Forms.Button();
            this.btSua_NXB = new System.Windows.Forms.Button();
            this.btThem_NXB = new System.Windows.Forms.Button();
            this.txtGhiChu_NXB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtTenNXB_NXB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMaNXB_NXB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimKiem_NXB)).BeginInit();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.DarkCyan;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(864, 40);
            this.label1.TabIndex = 7;
            this.label1.Text = "NHÀ XUẤT BẢN";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.dgvTimKiem_NXB);
            this.panel3.Location = new System.Drawing.Point(12, 282);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(840, 236);
            this.panel3.TabIndex = 9;
            // 
            // dgvTimKiem_NXB
            // 
            this.dgvTimKiem_NXB.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTimKiem_NXB.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvTimKiem_NXB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvTimKiem_NXB.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvTimKiem_NXB.Location = new System.Drawing.Point(10, 6);
            this.dgvTimKiem_NXB.Name = "dgvTimKiem_NXB";
            this.dgvTimKiem_NXB.RowTemplate.Height = 26;
            this.dgvTimKiem_NXB.Size = new System.Drawing.Size(818, 223);
            this.dgvTimKiem_NXB.TabIndex = 86;
            this.dgvTimKiem_NXB.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvTimKiem_NXB_RowEnter);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btTrangChu_NXB);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.btHuy_NXB);
            this.panel2.Controls.Add(this.btCapNhat_NXB);
            this.panel2.Controls.Add(this.btXoa_NXB);
            this.panel2.Controls.Add(this.btSua_NXB);
            this.panel2.Controls.Add(this.btThem_NXB);
            this.panel2.Controls.Add(this.txtGhiChu_NXB);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.txtTenNXB_NXB);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtMaNXB_NXB);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(12, 51);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(840, 218);
            this.panel2.TabIndex = 8;
            // 
            // btTrangChu_NXB
            // 
            this.btTrangChu_NXB.BackColor = System.Drawing.Color.DarkCyan;
            this.btTrangChu_NXB.FlatAppearance.BorderSize = 0;
            this.btTrangChu_NXB.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btTrangChu_NXB.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btTrangChu_NXB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btTrangChu_NXB.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btTrangChu_NXB.ForeColor = System.Drawing.Color.White;
            this.btTrangChu_NXB.Location = new System.Drawing.Point(670, 168);
            this.btTrangChu_NXB.Name = "btTrangChu_NXB";
            this.btTrangChu_NXB.Size = new System.Drawing.Size(109, 33);
            this.btTrangChu_NXB.TabIndex = 78;
            this.btTrangChu_NXB.Text = "TRANG CHỦ";
            this.btTrangChu_NXB.UseVisualStyleBackColor = false;
            this.btTrangChu_NXB.Click += new System.EventHandler(this.btTrangChu_NXB_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtTimKiem_NXB);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(444, 39);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(360, 66);
            this.groupBox1.TabIndex = 85;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tìm Kiếm";
            // 
            // txtTimKiem_NXB
            // 
            this.txtTimKiem_NXB.Location = new System.Drawing.Point(15, 29);
            this.txtTimKiem_NXB.Name = "txtTimKiem_NXB";
            this.txtTimKiem_NXB.Size = new System.Drawing.Size(330, 26);
            this.txtTimKiem_NXB.TabIndex = 86;
            this.txtTimKiem_NXB.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtTimKiem_NXB_KeyUp);
            // 
            // btHuy_NXB
            // 
            this.btHuy_NXB.BackColor = System.Drawing.Color.DarkCyan;
            this.btHuy_NXB.FlatAppearance.BorderSize = 0;
            this.btHuy_NXB.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_NXB.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_NXB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btHuy_NXB.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btHuy_NXB.ForeColor = System.Drawing.Color.White;
            this.btHuy_NXB.Location = new System.Drawing.Point(548, 168);
            this.btHuy_NXB.Name = "btHuy_NXB";
            this.btHuy_NXB.Size = new System.Drawing.Size(109, 33);
            this.btHuy_NXB.TabIndex = 77;
            this.btHuy_NXB.Text = "HỦY";
            this.btHuy_NXB.UseVisualStyleBackColor = false;
            this.btHuy_NXB.Click += new System.EventHandler(this.btHuy_NXB_Click);
            // 
            // btCapNhat_NXB
            // 
            this.btCapNhat_NXB.BackColor = System.Drawing.Color.DarkCyan;
            this.btCapNhat_NXB.FlatAppearance.BorderSize = 0;
            this.btCapNhat_NXB.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_NXB.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_NXB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCapNhat_NXB.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCapNhat_NXB.ForeColor = System.Drawing.Color.White;
            this.btCapNhat_NXB.Location = new System.Drawing.Point(426, 168);
            this.btCapNhat_NXB.Name = "btCapNhat_NXB";
            this.btCapNhat_NXB.Size = new System.Drawing.Size(109, 33);
            this.btCapNhat_NXB.TabIndex = 76;
            this.btCapNhat_NXB.Text = "CẬP NHẬT";
            this.btCapNhat_NXB.UseVisualStyleBackColor = false;
            this.btCapNhat_NXB.Click += new System.EventHandler(this.btCapNhat_NXB_Click);
            // 
            // btXoa_NXB
            // 
            this.btXoa_NXB.BackColor = System.Drawing.Color.DarkCyan;
            this.btXoa_NXB.FlatAppearance.BorderSize = 0;
            this.btXoa_NXB.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btXoa_NXB.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btXoa_NXB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btXoa_NXB.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoa_NXB.ForeColor = System.Drawing.Color.White;
            this.btXoa_NXB.Location = new System.Drawing.Point(304, 168);
            this.btXoa_NXB.Name = "btXoa_NXB";
            this.btXoa_NXB.Size = new System.Drawing.Size(109, 33);
            this.btXoa_NXB.TabIndex = 75;
            this.btXoa_NXB.Text = "XÓA";
            this.btXoa_NXB.UseVisualStyleBackColor = false;
            this.btXoa_NXB.Click += new System.EventHandler(this.btXoa_NXB_Click);
            // 
            // btSua_NXB
            // 
            this.btSua_NXB.BackColor = System.Drawing.Color.DarkCyan;
            this.btSua_NXB.FlatAppearance.BorderSize = 0;
            this.btSua_NXB.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btSua_NXB.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btSua_NXB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btSua_NXB.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btSua_NXB.ForeColor = System.Drawing.Color.White;
            this.btSua_NXB.Location = new System.Drawing.Point(182, 168);
            this.btSua_NXB.Name = "btSua_NXB";
            this.btSua_NXB.Size = new System.Drawing.Size(109, 33);
            this.btSua_NXB.TabIndex = 74;
            this.btSua_NXB.Text = "SỬA";
            this.btSua_NXB.UseVisualStyleBackColor = false;
            this.btSua_NXB.Click += new System.EventHandler(this.btSua_NXB_Click);
            // 
            // btThem_NXB
            // 
            this.btThem_NXB.BackColor = System.Drawing.Color.DarkCyan;
            this.btThem_NXB.FlatAppearance.BorderSize = 0;
            this.btThem_NXB.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btThem_NXB.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btThem_NXB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btThem_NXB.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThem_NXB.ForeColor = System.Drawing.Color.White;
            this.btThem_NXB.Location = new System.Drawing.Point(60, 168);
            this.btThem_NXB.Name = "btThem_NXB";
            this.btThem_NXB.Size = new System.Drawing.Size(109, 33);
            this.btThem_NXB.TabIndex = 73;
            this.btThem_NXB.Text = "THÊM";
            this.btThem_NXB.UseVisualStyleBackColor = false;
            this.btThem_NXB.Click += new System.EventHandler(this.btThem_NXB_Click);
            // 
            // txtGhiChu_NXB
            // 
            this.txtGhiChu_NXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGhiChu_NXB.Location = new System.Drawing.Point(140, 106);
            this.txtGhiChu_NXB.Name = "txtGhiChu_NXB";
            this.txtGhiChu_NXB.Size = new System.Drawing.Size(223, 24);
            this.txtGhiChu_NXB.TabIndex = 72;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(14, 103);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 23);
            this.label6.TabIndex = 71;
            this.label6.Text = "Ghi chú:";
            // 
            // txtTenNXB_NXB
            // 
            this.txtTenNXB_NXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenNXB_NXB.Location = new System.Drawing.Point(140, 65);
            this.txtTenNXB_NXB.Name = "txtTenNXB_NXB";
            this.txtTenNXB_NXB.Size = new System.Drawing.Size(223, 24);
            this.txtTenNXB_NXB.TabIndex = 60;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(14, 62);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 23);
            this.label3.TabIndex = 59;
            this.label3.Text = "Tên NXB:";
            // 
            // txtMaNXB_NXB
            // 
            this.txtMaNXB_NXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaNXB_NXB.Location = new System.Drawing.Point(140, 22);
            this.txtMaNXB_NXB.Name = "txtMaNXB_NXB";
            this.txtMaNXB_NXB.Size = new System.Drawing.Size(223, 24);
            this.txtMaNXB_NXB.TabIndex = 58;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(14, 19);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 23);
            this.label2.TabIndex = 57;
            this.label2.Text = "Mã NXB:";
            // 
            // NhaXuatBan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(864, 526);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label1);
            this.Name = "NhaXuatBan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NhaXuatBan";
            this.Load += new System.EventHandler(this.NhaXuatBan_Load);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTimKiem_NXB)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dgvTimKiem_NXB;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btTrangChu_NXB;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtTimKiem_NXB;
        private System.Windows.Forms.Button btHuy_NXB;
        private System.Windows.Forms.Button btCapNhat_NXB;
        private System.Windows.Forms.Button btXoa_NXB;
        private System.Windows.Forms.Button btSua_NXB;
        private System.Windows.Forms.Button btThem_NXB;
        private System.Windows.Forms.TextBox txtGhiChu_NXB;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtTenNXB_NXB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMaNXB_NXB;
        private System.Windows.Forms.Label label2;
    }
}