﻿namespace QLThuVien
{
    partial class TrangChuUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pageSetupDialog1 = new System.Windows.Forms.PageSetupDialog();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btUDangXuat = new System.Windows.Forms.Button();
            this.bt_UTTCaNhan = new System.Windows.Forms.Button();
            this.bt_USachQuaHan = new System.Windows.Forms.Button();
            this.bt_USachDangMuon = new System.Windows.Forms.Button();
            this.bt_UTimKiemSach = new System.Windows.Forms.Button();
            this.bt_UTrangChu = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblXinChaoUser = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.bt_USachDaDat = new System.Windows.Forms.Button();
            this.uSachDaDat1 = new QLThuVien.USachDaDat();
            this.uSachDangMuon1 = new QLThuVien.USachDangMuon();
            this.uTimKiemSach1 = new QLThuVien.UTimKiemSach();
            this.uttCaNhan1 = new QLThuVien.UTTCaNhan();
            this.uSachQuaHan1 = new QLThuVien.USachQuaHan();
            this.home1 = new QLThuVien.home();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1084, 35);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(1055, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 24);
            this.label1.TabIndex = 3;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(6, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 24);
            this.label2.TabIndex = 2;
            this.label2.Text = "THƯ VIỆN";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkCyan;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.bt_USachDaDat);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.btUDangXuat);
            this.panel2.Controls.Add(this.bt_UTTCaNhan);
            this.panel2.Controls.Add(this.bt_USachQuaHan);
            this.panel2.Controls.Add(this.bt_USachDangMuon);
            this.panel2.Controls.Add(this.bt_UTimKiemSach);
            this.panel2.Controls.Add(this.bt_UTrangChu);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 35);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(220, 526);
            this.panel2.TabIndex = 1;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::QLThuVien.Properties.Resources.logout;
            this.pictureBox2.Location = new System.Drawing.Point(48, 479);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(34, 29);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            // 
            // btUDangXuat
            // 
            this.btUDangXuat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btUDangXuat.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btUDangXuat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btUDangXuat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btUDangXuat.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btUDangXuat.ForeColor = System.Drawing.Color.White;
            this.btUDangXuat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btUDangXuat.Location = new System.Drawing.Point(44, 473);
            this.btUDangXuat.Name = "btUDangXuat";
            this.btUDangXuat.Size = new System.Drawing.Size(124, 40);
            this.btUDangXuat.TabIndex = 19;
            this.btUDangXuat.Text = "Đăng xuất";
            this.btUDangXuat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btUDangXuat.UseVisualStyleBackColor = true;
            this.btUDangXuat.Click += new System.EventHandler(this.btUDangXuat_Click);
            // 
            // bt_UTTCaNhan
            // 
            this.bt_UTTCaNhan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_UTTCaNhan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_UTTCaNhan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_UTTCaNhan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_UTTCaNhan.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_UTTCaNhan.ForeColor = System.Drawing.Color.White;
            this.bt_UTTCaNhan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_UTTCaNhan.Location = new System.Drawing.Point(10, 411);
            this.bt_UTTCaNhan.Name = "bt_UTTCaNhan";
            this.bt_UTTCaNhan.Size = new System.Drawing.Size(200, 40);
            this.bt_UTTCaNhan.TabIndex = 17;
            this.bt_UTTCaNhan.Text = "THÔNG TIN CÁ NHÂN";
            this.bt_UTTCaNhan.UseVisualStyleBackColor = true;
            this.bt_UTTCaNhan.Click += new System.EventHandler(this.bt_UTTCaNhan_Click);
            // 
            // bt_USachQuaHan
            // 
            this.bt_USachQuaHan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_USachQuaHan.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_USachQuaHan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_USachQuaHan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_USachQuaHan.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_USachQuaHan.ForeColor = System.Drawing.Color.White;
            this.bt_USachQuaHan.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_USachQuaHan.Location = new System.Drawing.Point(10, 318);
            this.bt_USachQuaHan.Name = "bt_USachQuaHan";
            this.bt_USachQuaHan.Size = new System.Drawing.Size(200, 40);
            this.bt_USachQuaHan.TabIndex = 16;
            this.bt_USachQuaHan.Text = "SÁCH QUÁ HẠN";
            this.bt_USachQuaHan.UseVisualStyleBackColor = true;
            this.bt_USachQuaHan.Click += new System.EventHandler(this.bt_USachQuaHan_Click);
            // 
            // bt_USachDangMuon
            // 
            this.bt_USachDangMuon.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_USachDangMuon.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_USachDangMuon.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_USachDangMuon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_USachDangMuon.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_USachDangMuon.ForeColor = System.Drawing.Color.White;
            this.bt_USachDangMuon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_USachDangMuon.Location = new System.Drawing.Point(11, 272);
            this.bt_USachDangMuon.Name = "bt_USachDangMuon";
            this.bt_USachDangMuon.Size = new System.Drawing.Size(200, 40);
            this.bt_USachDangMuon.TabIndex = 15;
            this.bt_USachDangMuon.Text = "SÁCH ĐANG MƯỢN";
            this.bt_USachDangMuon.UseVisualStyleBackColor = true;
            this.bt_USachDangMuon.Click += new System.EventHandler(this.bt_USachDangMuon_Click);
            // 
            // bt_UTimKiemSach
            // 
            this.bt_UTimKiemSach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_UTimKiemSach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_UTimKiemSach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_UTimKiemSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_UTimKiemSach.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_UTimKiemSach.ForeColor = System.Drawing.Color.White;
            this.bt_UTimKiemSach.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_UTimKiemSach.Location = new System.Drawing.Point(10, 226);
            this.bt_UTimKiemSach.Name = "bt_UTimKiemSach";
            this.bt_UTimKiemSach.Size = new System.Drawing.Size(200, 40);
            this.bt_UTimKiemSach.TabIndex = 14;
            this.bt_UTimKiemSach.Text = "TÌM KIẾM SÁCH";
            this.bt_UTimKiemSach.UseVisualStyleBackColor = true;
            this.bt_UTimKiemSach.Click += new System.EventHandler(this.bt_UTimKiemSach_Click);
            // 
            // bt_UTrangChu
            // 
            this.bt_UTrangChu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_UTrangChu.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_UTrangChu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_UTrangChu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_UTrangChu.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_UTrangChu.ForeColor = System.Drawing.Color.White;
            this.bt_UTrangChu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_UTrangChu.Location = new System.Drawing.Point(10, 180);
            this.bt_UTrangChu.Name = "bt_UTrangChu";
            this.bt_UTrangChu.Size = new System.Drawing.Size(200, 40);
            this.bt_UTrangChu.TabIndex = 13;
            this.bt_UTrangChu.Text = "TRANG CHỦ";
            this.bt_UTrangChu.UseVisualStyleBackColor = true;
            this.bt_UTrangChu.Click += new System.EventHandler(this.bt_UTrangChu_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lblXinChaoUser);
            this.panel4.Location = new System.Drawing.Point(10, 136);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(198, 28);
            this.panel4.TabIndex = 12;
            // 
            // lblXinChaoUser
            // 
            this.lblXinChaoUser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblXinChaoUser.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXinChaoUser.ForeColor = System.Drawing.Color.White;
            this.lblXinChaoUser.Location = new System.Drawing.Point(0, 0);
            this.lblXinChaoUser.Name = "lblXinChaoUser";
            this.lblXinChaoUser.Size = new System.Drawing.Size(198, 28);
            this.lblXinChaoUser.TabIndex = 0;
            this.lblXinChaoUser.Text = "label3";
            this.lblXinChaoUser.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::QLThuVien.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(58, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.home1);
            this.panel3.Controls.Add(this.uSachDaDat1);
            this.panel3.Controls.Add(this.uSachDangMuon1);
            this.panel3.Controls.Add(this.uTimKiemSach1);
            this.panel3.Controls.Add(this.uttCaNhan1);
            this.panel3.Controls.Add(this.uSachQuaHan1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(220, 35);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(864, 526);
            this.panel3.TabIndex = 2;
            // 
            // bt_USachDaDat
            // 
            this.bt_USachDaDat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_USachDaDat.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_USachDaDat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_USachDaDat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_USachDaDat.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_USachDaDat.ForeColor = System.Drawing.Color.White;
            this.bt_USachDaDat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_USachDaDat.Location = new System.Drawing.Point(10, 364);
            this.bt_USachDaDat.Name = "bt_USachDaDat";
            this.bt_USachDaDat.Size = new System.Drawing.Size(200, 40);
            this.bt_USachDaDat.TabIndex = 20;
            this.bt_USachDaDat.Text = "SÁCH ĐÃ ĐẶT";
            this.bt_USachDaDat.UseVisualStyleBackColor = true;
            this.bt_USachDaDat.Click += new System.EventHandler(this.bt_USachDaDat_Click);
            // 
            // uSachDaDat1
            // 
            this.uSachDaDat1.BackColor = System.Drawing.Color.White;
            this.uSachDaDat1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.uSachDaDat1.Location = new System.Drawing.Point(-1, -1);
            this.uSachDaDat1.Name = "uSachDaDat1";
            this.uSachDaDat1.Size = new System.Drawing.Size(864, 526);
            this.uSachDaDat1.TabIndex = 5;
            // 
            // uSachDangMuon1
            // 
            this.uSachDangMuon1.Location = new System.Drawing.Point(-1, -1);
            this.uSachDangMuon1.Name = "uSachDangMuon1";
            this.uSachDangMuon1.Size = new System.Drawing.Size(880, 565);
            this.uSachDangMuon1.TabIndex = 3;
            // 
            // uTimKiemSach1
            // 
            this.uTimKiemSach1.Location = new System.Drawing.Point(-1, -1);
            this.uTimKiemSach1.Name = "uTimKiemSach1";
            this.uTimKiemSach1.Size = new System.Drawing.Size(880, 565);
            this.uTimKiemSach1.TabIndex = 2;
            // 
            // uttCaNhan1
            // 
            this.uttCaNhan1.Location = new System.Drawing.Point(-1, -1);
            this.uttCaNhan1.Name = "uttCaNhan1";
            this.uttCaNhan1.Size = new System.Drawing.Size(880, 565);
            this.uttCaNhan1.TabIndex = 1;
            // 
            // uSachQuaHan1
            // 
            this.uSachQuaHan1.Location = new System.Drawing.Point(-1, -1);
            this.uSachQuaHan1.Name = "uSachQuaHan1";
            this.uSachQuaHan1.Size = new System.Drawing.Size(880, 565);
            this.uSachQuaHan1.TabIndex = 0;
            // 
            // home1
            // 
            this.home1.Location = new System.Drawing.Point(-1, -3);
            this.home1.Name = "home1";
            this.home1.Size = new System.Drawing.Size(880, 565);
            this.home1.TabIndex = 6;
            // 
            // TrangChuUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1084, 561);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TrangChuUser";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TrangChuUser";
            this.Load += new System.EventHandler(this.TrangChuUser_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PageSetupDialog pageSetupDialog1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblXinChaoUser;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button bt_UTTCaNhan;
        private System.Windows.Forms.Button bt_USachQuaHan;
        private System.Windows.Forms.Button bt_USachDangMuon;
        private System.Windows.Forms.Button bt_UTimKiemSach;
        private System.Windows.Forms.Button bt_UTrangChu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btUDangXuat;
        private USachDangMuon uSachDangMuon1;
        private UTimKiemSach uTimKiemSach1;
        private UTTCaNhan uttCaNhan1;
        private USachQuaHan uSachQuaHan1;
        private System.Windows.Forms.Button bt_USachDaDat;
        private USachDaDat uSachDaDat1;
        private home home1;
    }
}