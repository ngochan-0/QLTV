﻿namespace QLThuVien
{
    partial class QLDocGia
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtMatKhau_QLDG = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbGioiTinh_QLDG = new System.Windows.Forms.ComboBox();
            this.btHuy_QLDG = new System.Windows.Forms.Button();
            this.btCapNhat_QLDG = new System.Windows.Forms.Button();
            this.btXoa_QLDG = new System.Windows.Forms.Button();
            this.btThem_QLDG = new System.Windows.Forms.Button();
            this.txtSDT_QLDG = new System.Windows.Forms.TextBox();
            this.txtDiaChi_QLDG = new System.Windows.Forms.TextBox();
            this.txtTenDG_QLDG = new System.Windows.Forms.TextBox();
            this.txtMaDG_QLDG = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtTimKiemDocGia = new System.Windows.Forms.TextBox();
            this.rbTenDG_QLDG = new System.Windows.Forms.RadioButton();
            this.rbMaDG_QLDG = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dgvDocGia = new System.Windows.Forms.DataGridView();
            this.txtEmail_QLDG = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocGia)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.txtEmail_QLDG);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtMatKhau_QLDG);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.cbGioiTinh_QLDG);
            this.panel1.Controls.Add(this.btHuy_QLDG);
            this.panel1.Controls.Add(this.btCapNhat_QLDG);
            this.panel1.Controls.Add(this.btXoa_QLDG);
            this.panel1.Controls.Add(this.btThem_QLDG);
            this.panel1.Controls.Add(this.txtSDT_QLDG);
            this.panel1.Controls.Add(this.txtDiaChi_QLDG);
            this.panel1.Controls.Add(this.txtTenDG_QLDG);
            this.panel1.Controls.Add(this.txtMaDG_QLDG);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Location = new System.Drawing.Point(12, 15);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(368, 534);
            this.panel1.TabIndex = 0;
            // 
            // txtMatKhau_QLDG
            // 
            this.txtMatKhau_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatKhau_QLDG.Location = new System.Drawing.Point(156, 358);
            this.txtMatKhau_QLDG.Name = "txtMatKhau_QLDG";
            this.txtMatKhau_QLDG.Size = new System.Drawing.Size(194, 24);
            this.txtMatKhau_QLDG.TabIndex = 67;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(18, 357);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 23);
            this.label2.TabIndex = 65;
            this.label2.Text = "Mật khẩu:";
            // 
            // cbGioiTinh_QLDG
            // 
            this.cbGioiTinh_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbGioiTinh_QLDG.FormattingEnabled = true;
            this.cbGioiTinh_QLDG.Items.AddRange(new object[] {
            "Nam",
            "Nữ"});
            this.cbGioiTinh_QLDG.Location = new System.Drawing.Point(156, 225);
            this.cbGioiTinh_QLDG.Name = "cbGioiTinh_QLDG";
            this.cbGioiTinh_QLDG.Size = new System.Drawing.Size(194, 26);
            this.cbGioiTinh_QLDG.TabIndex = 64;
            // 
            // btHuy_QLDG
            // 
            this.btHuy_QLDG.BackColor = System.Drawing.Color.DarkCyan;
            this.btHuy_QLDG.FlatAppearance.BorderSize = 0;
            this.btHuy_QLDG.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_QLDG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_QLDG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btHuy_QLDG.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btHuy_QLDG.ForeColor = System.Drawing.Color.White;
            this.btHuy_QLDG.Location = new System.Drawing.Point(200, 489);
            this.btHuy_QLDG.Name = "btHuy_QLDG";
            this.btHuy_QLDG.Size = new System.Drawing.Size(96, 33);
            this.btHuy_QLDG.TabIndex = 63;
            this.btHuy_QLDG.Text = "HỦY";
            this.btHuy_QLDG.UseVisualStyleBackColor = false;
            this.btHuy_QLDG.Click += new System.EventHandler(this.btHuy_QLDG_Click);
            // 
            // btCapNhat_QLDG
            // 
            this.btCapNhat_QLDG.BackColor = System.Drawing.Color.DarkCyan;
            this.btCapNhat_QLDG.FlatAppearance.BorderSize = 0;
            this.btCapNhat_QLDG.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_QLDG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_QLDG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCapNhat_QLDG.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCapNhat_QLDG.ForeColor = System.Drawing.Color.White;
            this.btCapNhat_QLDG.Location = new System.Drawing.Point(71, 489);
            this.btCapNhat_QLDG.Name = "btCapNhat_QLDG";
            this.btCapNhat_QLDG.Size = new System.Drawing.Size(96, 33);
            this.btCapNhat_QLDG.TabIndex = 62;
            this.btCapNhat_QLDG.Text = "CẬP NHẬT";
            this.btCapNhat_QLDG.UseVisualStyleBackColor = false;
            this.btCapNhat_QLDG.Click += new System.EventHandler(this.btCapNhat_QLDG_Click);
            // 
            // btXoa_QLDG
            // 
            this.btXoa_QLDG.BackColor = System.Drawing.Color.DarkCyan;
            this.btXoa_QLDG.FlatAppearance.BorderSize = 0;
            this.btXoa_QLDG.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btXoa_QLDG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btXoa_QLDG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btXoa_QLDG.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btXoa_QLDG.ForeColor = System.Drawing.Color.White;
            this.btXoa_QLDG.Location = new System.Drawing.Point(235, 442);
            this.btXoa_QLDG.Name = "btXoa_QLDG";
            this.btXoa_QLDG.Size = new System.Drawing.Size(96, 33);
            this.btXoa_QLDG.TabIndex = 61;
            this.btXoa_QLDG.Text = "XÓA";
            this.btXoa_QLDG.UseVisualStyleBackColor = false;
            this.btXoa_QLDG.Click += new System.EventHandler(this.btXoa_QLDG_Click);
            // 
            // btThem_QLDG
            // 
            this.btThem_QLDG.BackColor = System.Drawing.Color.DarkCyan;
            this.btThem_QLDG.FlatAppearance.BorderSize = 0;
            this.btThem_QLDG.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btThem_QLDG.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btThem_QLDG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btThem_QLDG.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThem_QLDG.ForeColor = System.Drawing.Color.White;
            this.btThem_QLDG.Location = new System.Drawing.Point(36, 442);
            this.btThem_QLDG.Name = "btThem_QLDG";
            this.btThem_QLDG.Size = new System.Drawing.Size(96, 33);
            this.btThem_QLDG.TabIndex = 59;
            this.btThem_QLDG.Text = "THÊM";
            this.btThem_QLDG.UseVisualStyleBackColor = false;
            this.btThem_QLDG.Click += new System.EventHandler(this.btThem_QLDG_Click);
            // 
            // txtSDT_QLDG
            // 
            this.txtSDT_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDT_QLDG.Location = new System.Drawing.Point(156, 314);
            this.txtSDT_QLDG.Name = "txtSDT_QLDG";
            this.txtSDT_QLDG.Size = new System.Drawing.Size(194, 24);
            this.txtSDT_QLDG.TabIndex = 57;
            // 
            // txtDiaChi_QLDG
            // 
            this.txtDiaChi_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiaChi_QLDG.Location = new System.Drawing.Point(156, 270);
            this.txtDiaChi_QLDG.Name = "txtDiaChi_QLDG";
            this.txtDiaChi_QLDG.Size = new System.Drawing.Size(194, 24);
            this.txtDiaChi_QLDG.TabIndex = 56;
            // 
            // txtTenDG_QLDG
            // 
            this.txtTenDG_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDG_QLDG.Location = new System.Drawing.Point(156, 181);
            this.txtTenDG_QLDG.Name = "txtTenDG_QLDG";
            this.txtTenDG_QLDG.Size = new System.Drawing.Size(194, 24);
            this.txtTenDG_QLDG.TabIndex = 54;
            // 
            // txtMaDG_QLDG
            // 
            this.txtMaDG_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaDG_QLDG.Location = new System.Drawing.Point(156, 137);
            this.txtMaDG_QLDG.Name = "txtMaDG_QLDG";
            this.txtMaDG_QLDG.Size = new System.Drawing.Size(194, 24);
            this.txtMaDG_QLDG.TabIndex = 53;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(18, 313);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(114, 23);
            this.label7.TabIndex = 51;
            this.label7.Text = "Số điện thoại:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(18, 269);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 23);
            this.label6.TabIndex = 50;
            this.label6.Text = "Địa chỉ:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(18, 225);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 23);
            this.label5.TabIndex = 49;
            this.label5.Text = "Giới tính:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(18, 181);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 23);
            this.label4.TabIndex = 48;
            this.label4.Text = "Họ và tên:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(18, 137);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 23);
            this.label3.TabIndex = 47;
            this.label3.Text = "Mã độc giả:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtTimKiemDocGia);
            this.groupBox2.Controls.Add(this.rbTenDG_QLDG);
            this.groupBox2.Controls.Add(this.rbMaDG_QLDG);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(14, 15);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(336, 110);
            this.groupBox2.TabIndex = 46;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tìm Kiếm Độc Giả";
            // 
            // txtTimKiemDocGia
            // 
            this.txtTimKiemDocGia.Location = new System.Drawing.Point(19, 74);
            this.txtTimKiemDocGia.Name = "txtTimKiemDocGia";
            this.txtTimKiemDocGia.Size = new System.Drawing.Size(298, 24);
            this.txtTimKiemDocGia.TabIndex = 55;
            this.txtTimKiemDocGia.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtTimKiemDocGia_KeyUp);
            // 
            // rbTenDG_QLDG
            // 
            this.rbTenDG_QLDG.AutoSize = true;
            this.rbTenDG_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbTenDG_QLDG.Location = new System.Drawing.Point(209, 34);
            this.rbTenDG_QLDG.Margin = new System.Windows.Forms.Padding(2);
            this.rbTenDG_QLDG.Name = "rbTenDG_QLDG";
            this.rbTenDG_QLDG.Size = new System.Drawing.Size(103, 22);
            this.rbTenDG_QLDG.TabIndex = 1;
            this.rbTenDG_QLDG.TabStop = true;
            this.rbTenDG_QLDG.Text = "Tên độc giả";
            this.rbTenDG_QLDG.UseVisualStyleBackColor = true;
            // 
            // rbMaDG_QLDG
            // 
            this.rbMaDG_QLDG.AutoSize = true;
            this.rbMaDG_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbMaDG_QLDG.Location = new System.Drawing.Point(19, 34);
            this.rbMaDG_QLDG.Margin = new System.Windows.Forms.Padding(2);
            this.rbMaDG_QLDG.Name = "rbMaDG_QLDG";
            this.rbMaDG_QLDG.Size = new System.Drawing.Size(99, 22);
            this.rbMaDG_QLDG.TabIndex = 0;
            this.rbMaDG_QLDG.TabStop = true;
            this.rbMaDG_QLDG.Text = "Mã độc giả";
            this.rbMaDG_QLDG.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.dgvDocGia);
            this.panel2.Location = new System.Drawing.Point(401, 15);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(459, 534);
            this.panel2.TabIndex = 1;
            // 
            // dgvDocGia
            // 
            this.dgvDocGia.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDocGia.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvDocGia.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 11F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvDocGia.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvDocGia.Location = new System.Drawing.Point(18, 18);
            this.dgvDocGia.Name = "dgvDocGia";
            this.dgvDocGia.RowTemplate.Height = 26;
            this.dgvDocGia.Size = new System.Drawing.Size(422, 497);
            this.dgvDocGia.TabIndex = 0;
            this.dgvDocGia.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDocGia_RowEnter);
            // 
            // txtEmail_QLDG
            // 
            this.txtEmail_QLDG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail_QLDG.Location = new System.Drawing.Point(156, 402);
            this.txtEmail_QLDG.Name = "txtEmail_QLDG";
            this.txtEmail_QLDG.Size = new System.Drawing.Size(194, 24);
            this.txtEmail_QLDG.TabIndex = 69;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(18, 401);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 23);
            this.label1.TabIndex = 68;
            this.label1.Text = "Email:";
            // 
            // QLDocGia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "QLDocGia";
            this.Size = new System.Drawing.Size(880, 565);
            this.Load += new System.EventHandler(this.QLDocGia_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDocGia)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton rbTenDG_QLDG;
        private System.Windows.Forms.RadioButton rbMaDG_QLDG;
        private System.Windows.Forms.DataGridView dgvDocGia;
        private System.Windows.Forms.TextBox txtTimKiemDocGia;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMaDG_QLDG;
        private System.Windows.Forms.TextBox txtSDT_QLDG;
        private System.Windows.Forms.TextBox txtDiaChi_QLDG;
        private System.Windows.Forms.TextBox txtTenDG_QLDG;
        private System.Windows.Forms.Button btHuy_QLDG;
        private System.Windows.Forms.Button btCapNhat_QLDG;
        private System.Windows.Forms.Button btXoa_QLDG;
        private System.Windows.Forms.Button btThem_QLDG;
        private System.Windows.Forms.ComboBox cbGioiTinh_QLDG;
        private System.Windows.Forms.TextBox txtMatKhau_QLDG;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtEmail_QLDG;
        private System.Windows.Forms.Label label1;
    }
}
