﻿namespace QLThuVien
{
    partial class DoiMatKhau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMaNV_DoiMatKhau = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btHuy_DoiMatKhau = new System.Windows.Forms.Button();
            this.btCapNhat_DoiMatKhau = new System.Windows.Forms.Button();
            this.txtMKCu_DoiMatKhau = new System.Windows.Forms.TextBox();
            this.txtMKMoi_DoiMatKhau = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.DarkCyan;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(494, 40);
            this.label1.TabIndex = 8;
            this.label1.Text = "ĐỔI MẬT KHẨU";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(58, 159);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 23);
            this.label6.TabIndex = 77;
            this.label6.Text = "Mật khẩu mới:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(58, 118);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 23);
            this.label3.TabIndex = 75;
            this.label3.Text = "Mật khẩu cũ:";
            // 
            // txtMaNV_DoiMatKhau
            // 
            this.txtMaNV_DoiMatKhau.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaNV_DoiMatKhau.Location = new System.Drawing.Point(199, 78);
            this.txtMaNV_DoiMatKhau.Name = "txtMaNV_DoiMatKhau";
            this.txtMaNV_DoiMatKhau.Size = new System.Drawing.Size(223, 22);
            this.txtMaNV_DoiMatKhau.TabIndex = 74;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(58, 75);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 23);
            this.label2.TabIndex = 73;
            this.label2.Text = "Mã nhân viên:";
            // 
            // btHuy_DoiMatKhau
            // 
            this.btHuy_DoiMatKhau.BackColor = System.Drawing.Color.DarkCyan;
            this.btHuy_DoiMatKhau.FlatAppearance.BorderSize = 0;
            this.btHuy_DoiMatKhau.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_DoiMatKhau.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btHuy_DoiMatKhau.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btHuy_DoiMatKhau.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btHuy_DoiMatKhau.ForeColor = System.Drawing.Color.White;
            this.btHuy_DoiMatKhau.Location = new System.Drawing.Point(305, 211);
            this.btHuy_DoiMatKhau.Name = "btHuy_DoiMatKhau";
            this.btHuy_DoiMatKhau.Size = new System.Drawing.Size(109, 33);
            this.btHuy_DoiMatKhau.TabIndex = 80;
            this.btHuy_DoiMatKhau.Text = "HỦY";
            this.btHuy_DoiMatKhau.UseVisualStyleBackColor = false;
            this.btHuy_DoiMatKhau.Click += new System.EventHandler(this.btHuy_DoiMatKhau_Click);
            // 
            // btCapNhat_DoiMatKhau
            // 
            this.btCapNhat_DoiMatKhau.BackColor = System.Drawing.Color.DarkCyan;
            this.btCapNhat_DoiMatKhau.FlatAppearance.BorderSize = 0;
            this.btCapNhat_DoiMatKhau.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_DoiMatKhau.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btCapNhat_DoiMatKhau.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btCapNhat_DoiMatKhau.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btCapNhat_DoiMatKhau.ForeColor = System.Drawing.Color.White;
            this.btCapNhat_DoiMatKhau.Location = new System.Drawing.Point(69, 211);
            this.btCapNhat_DoiMatKhau.Name = "btCapNhat_DoiMatKhau";
            this.btCapNhat_DoiMatKhau.Size = new System.Drawing.Size(109, 33);
            this.btCapNhat_DoiMatKhau.TabIndex = 79;
            this.btCapNhat_DoiMatKhau.Text = "CẬP NHẬT";
            this.btCapNhat_DoiMatKhau.UseVisualStyleBackColor = false;
            this.btCapNhat_DoiMatKhau.Click += new System.EventHandler(this.btCapNhat_DoiMatKhau_Click);
            // 
            // txtMKCu_DoiMatKhau
            // 
            this.txtMKCu_DoiMatKhau.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMKCu_DoiMatKhau.Location = new System.Drawing.Point(199, 119);
            this.txtMKCu_DoiMatKhau.Name = "txtMKCu_DoiMatKhau";
            this.txtMKCu_DoiMatKhau.Size = new System.Drawing.Size(223, 22);
            this.txtMKCu_DoiMatKhau.TabIndex = 81;
            // 
            // txtMKMoi_DoiMatKhau
            // 
            this.txtMKMoi_DoiMatKhau.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMKMoi_DoiMatKhau.Location = new System.Drawing.Point(199, 160);
            this.txtMKMoi_DoiMatKhau.Name = "txtMKMoi_DoiMatKhau";
            this.txtMKMoi_DoiMatKhau.Size = new System.Drawing.Size(223, 22);
            this.txtMKMoi_DoiMatKhau.TabIndex = 82;
            // 
            // DoiMatKhau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(494, 262);
            this.Controls.Add(this.txtMKMoi_DoiMatKhau);
            this.Controls.Add(this.txtMKCu_DoiMatKhau);
            this.Controls.Add(this.btHuy_DoiMatKhau);
            this.Controls.Add(this.btCapNhat_DoiMatKhau);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtMaNV_DoiMatKhau);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "DoiMatKhau";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "DoiMatKhau";
            this.Load += new System.EventHandler(this.DoiMatKhau_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMaNV_DoiMatKhau;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btHuy_DoiMatKhau;
        private System.Windows.Forms.Button btCapNhat_DoiMatKhau;
        private System.Windows.Forms.TextBox txtMKCu_DoiMatKhau;
        private System.Windows.Forms.TextBox txtMKMoi_DoiMatKhau;
    }
}