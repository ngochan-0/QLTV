﻿namespace QLThuVien
{
    partial class TrangChu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btQLDatSach = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblXinChao = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btDangXuat = new System.Windows.Forms.Button();
            this.btThongke = new System.Windows.Forms.Button();
            this.btQLNhanVien = new System.Windows.Forms.Button();
            this.btQLDocGia = new System.Windows.Forms.Button();
            this.btQLMuonTra = new System.Windows.Forms.Button();
            this.btQLSach = new System.Windows.Forms.Button();
            this.bt_TrangChu = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.baoCao1 = new QLThuVien.BaoCao();
            this.qlSach1 = new QLThuVien.QLSach();
            this.qlNhanVien1 = new QLThuVien.QLNhanVien();
            this.qlMuonTra1 = new QLThuVien.QLMuonTra();
            this.qlDocGia1 = new QLThuVien.QLDocGia();
            this.qlDatSach1 = new QLThuVien.QLDatSach();
            this.home1 = new QLThuVien.home();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkCyan;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1100, 35);
            this.panel1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(7, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(276, 23);
            this.label2.TabIndex = 1;
            this.label2.Text = "HỆ THỐNG QUẢN LÝ THƯ VIỆN";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label1.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(1071, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkCyan;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.btQLDatSach);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.btDangXuat);
            this.panel2.Controls.Add(this.btThongke);
            this.panel2.Controls.Add(this.btQLNhanVien);
            this.panel2.Controls.Add(this.btQLDocGia);
            this.panel2.Controls.Add(this.btQLMuonTra);
            this.panel2.Controls.Add(this.btQLSach);
            this.panel2.Controls.Add(this.bt_TrangChu);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 35);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(220, 565);
            this.panel2.TabIndex = 1;
            // 
            // btQLDatSach
            // 
            this.btQLDatSach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btQLDatSach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btQLDatSach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btQLDatSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btQLDatSach.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btQLDatSach.ForeColor = System.Drawing.Color.White;
            this.btQLDatSach.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btQLDatSach.Location = new System.Drawing.Point(9, 405);
            this.btQLDatSach.Name = "btQLDatSach";
            this.btQLDatSach.Size = new System.Drawing.Size(200, 40);
            this.btQLDatSach.TabIndex = 11;
            this.btQLDatSach.Text = "QUẢN LÝ ĐẶT SÁCH";
            this.btQLDatSach.UseVisualStyleBackColor = true;
            this.btQLDatSach.Click += new System.EventHandler(this.btQLDatSach_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lblXinChao);
            this.panel4.Location = new System.Drawing.Point(11, 134);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(198, 28);
            this.panel4.TabIndex = 10;
            // 
            // lblXinChao
            // 
            this.lblXinChao.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblXinChao.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblXinChao.ForeColor = System.Drawing.Color.White;
            this.lblXinChao.Location = new System.Drawing.Point(0, 0);
            this.lblXinChao.Name = "lblXinChao";
            this.lblXinChao.Size = new System.Drawing.Size(198, 28);
            this.lblXinChao.TabIndex = 0;
            this.lblXinChao.Text = "label3";
            this.lblXinChao.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::QLThuVien.Properties.Resources.logout;
            this.pictureBox2.Location = new System.Drawing.Point(28, 518);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(34, 29);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // btDangXuat
            // 
            this.btDangXuat.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btDangXuat.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btDangXuat.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btDangXuat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btDangXuat.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btDangXuat.ForeColor = System.Drawing.Color.White;
            this.btDangXuat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btDangXuat.Location = new System.Drawing.Point(24, 512);
            this.btDangXuat.Name = "btDangXuat";
            this.btDangXuat.Size = new System.Drawing.Size(124, 40);
            this.btDangXuat.TabIndex = 9;
            this.btDangXuat.Text = "Đăng xuất";
            this.btDangXuat.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btDangXuat.UseVisualStyleBackColor = true;
            this.btDangXuat.Click += new System.EventHandler(this.btDangXuat_Click);
            // 
            // btThongke
            // 
            this.btThongke.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btThongke.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btThongke.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btThongke.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btThongke.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btThongke.ForeColor = System.Drawing.Color.White;
            this.btThongke.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btThongke.Location = new System.Drawing.Point(9, 451);
            this.btThongke.Name = "btThongke";
            this.btThongke.Size = new System.Drawing.Size(200, 40);
            this.btThongke.TabIndex = 8;
            this.btThongke.Text = "THỐNG KÊ";
            this.btThongke.UseVisualStyleBackColor = true;
            this.btThongke.Click += new System.EventHandler(this.btThongke_Click);
            // 
            // btQLNhanVien
            // 
            this.btQLNhanVien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btQLNhanVien.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btQLNhanVien.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btQLNhanVien.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btQLNhanVien.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btQLNhanVien.ForeColor = System.Drawing.Color.White;
            this.btQLNhanVien.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btQLNhanVien.Location = new System.Drawing.Point(9, 359);
            this.btQLNhanVien.Name = "btQLNhanVien";
            this.btQLNhanVien.Size = new System.Drawing.Size(200, 40);
            this.btQLNhanVien.TabIndex = 7;
            this.btQLNhanVien.Text = "QUẢN LÝ NHÂN VIÊN";
            this.btQLNhanVien.UseVisualStyleBackColor = true;
            this.btQLNhanVien.Click += new System.EventHandler(this.btQLNhanVien_Click);
            // 
            // btQLDocGia
            // 
            this.btQLDocGia.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btQLDocGia.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btQLDocGia.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btQLDocGia.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btQLDocGia.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btQLDocGia.ForeColor = System.Drawing.Color.White;
            this.btQLDocGia.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btQLDocGia.Location = new System.Drawing.Point(9, 313);
            this.btQLDocGia.Name = "btQLDocGia";
            this.btQLDocGia.Size = new System.Drawing.Size(200, 40);
            this.btQLDocGia.TabIndex = 6;
            this.btQLDocGia.Text = "QUẢN LÝ ĐỘC GIẢ";
            this.btQLDocGia.UseVisualStyleBackColor = true;
            this.btQLDocGia.Click += new System.EventHandler(this.btQLDocGia_Click);
            // 
            // btQLMuonTra
            // 
            this.btQLMuonTra.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btQLMuonTra.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btQLMuonTra.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btQLMuonTra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btQLMuonTra.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btQLMuonTra.ForeColor = System.Drawing.Color.White;
            this.btQLMuonTra.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btQLMuonTra.Location = new System.Drawing.Point(9, 267);
            this.btQLMuonTra.Name = "btQLMuonTra";
            this.btQLMuonTra.Size = new System.Drawing.Size(200, 40);
            this.btQLMuonTra.TabIndex = 5;
            this.btQLMuonTra.Text = "QUẢN LÝ MƯỢN TRẢ";
            this.btQLMuonTra.UseVisualStyleBackColor = true;
            this.btQLMuonTra.Click += new System.EventHandler(this.btQLMuonTra_Click);
            // 
            // btQLSach
            // 
            this.btQLSach.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btQLSach.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.btQLSach.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.btQLSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btQLSach.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btQLSach.ForeColor = System.Drawing.Color.White;
            this.btQLSach.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btQLSach.Location = new System.Drawing.Point(9, 221);
            this.btQLSach.Name = "btQLSach";
            this.btQLSach.Size = new System.Drawing.Size(200, 40);
            this.btQLSach.TabIndex = 4;
            this.btQLSach.Text = "QUẢN LÝ SÁCH";
            this.btQLSach.UseVisualStyleBackColor = true;
            this.btQLSach.Click += new System.EventHandler(this.btQLSach_Click);
            // 
            // bt_TrangChu
            // 
            this.bt_TrangChu.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bt_TrangChu.FlatAppearance.MouseDownBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_TrangChu.FlatAppearance.MouseOverBackColor = System.Drawing.Color.MediumTurquoise;
            this.bt_TrangChu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_TrangChu.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_TrangChu.ForeColor = System.Drawing.Color.White;
            this.bt_TrangChu.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.bt_TrangChu.Location = new System.Drawing.Point(9, 175);
            this.bt_TrangChu.Name = "bt_TrangChu";
            this.bt_TrangChu.Size = new System.Drawing.Size(200, 40);
            this.bt_TrangChu.TabIndex = 3;
            this.bt_TrangChu.Text = "TRANG CHỦ";
            this.bt_TrangChu.UseVisualStyleBackColor = true;
            this.bt_TrangChu.Click += new System.EventHandler(this.bt_TrangChu_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::QLThuVien.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(59, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 100);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.home1);
            this.panel3.Controls.Add(this.qlDatSach1);
            this.panel3.Controls.Add(this.baoCao1);
            this.panel3.Controls.Add(this.qlSach1);
            this.panel3.Controls.Add(this.qlNhanVien1);
            this.panel3.Controls.Add(this.qlMuonTra1);
            this.panel3.Controls.Add(this.qlDocGia1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(220, 35);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(880, 565);
            this.panel3.TabIndex = 2;
            // 
            // baoCao1
            // 
            this.baoCao1.Location = new System.Drawing.Point(0, 0);
            this.baoCao1.Name = "baoCao1";
            this.baoCao1.Size = new System.Drawing.Size(880, 565);
            this.baoCao1.TabIndex = 4;
            // 
            // qlSach1
            // 
            this.qlSach1.BackColor = System.Drawing.SystemColors.Control;
            this.qlSach1.Location = new System.Drawing.Point(0, 0);
            this.qlSach1.Name = "qlSach1";
            this.qlSach1.Size = new System.Drawing.Size(880, 565);
            this.qlSach1.TabIndex = 3;
            // 
            // qlNhanVien1
            // 
            this.qlNhanVien1.Location = new System.Drawing.Point(0, 0);
            this.qlNhanVien1.Name = "qlNhanVien1";
            this.qlNhanVien1.Size = new System.Drawing.Size(880, 565);
            this.qlNhanVien1.TabIndex = 2;
            // 
            // qlMuonTra1
            // 
            this.qlMuonTra1.Location = new System.Drawing.Point(0, 0);
            this.qlMuonTra1.Name = "qlMuonTra1";
            this.qlMuonTra1.Size = new System.Drawing.Size(880, 565);
            this.qlMuonTra1.TabIndex = 1;
            // 
            // qlDocGia1
            // 
            this.qlDocGia1.Location = new System.Drawing.Point(0, 0);
            this.qlDocGia1.Name = "qlDocGia1";
            this.qlDocGia1.Size = new System.Drawing.Size(880, 565);
            this.qlDocGia1.TabIndex = 0;
            // 
            // qlDatSach1
            // 
            this.qlDatSach1.BackColor = System.Drawing.Color.White;
            this.qlDatSach1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qlDatSach1.Location = new System.Drawing.Point(-1, -1);
            this.qlDatSach1.Name = "qlDatSach1";
            this.qlDatSach1.Size = new System.Drawing.Size(878, 563);
            this.qlDatSach1.TabIndex = 6;
            // 
            // home1
            // 
            this.home1.Location = new System.Drawing.Point(0, -3);
            this.home1.Name = "home1";
            this.home1.Size = new System.Drawing.Size(880, 565);
            this.home1.TabIndex = 7;
            // 
            // TrangChu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 600);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "TrangChu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TrangChu";
            this.Load += new System.EventHandler(this.TrangChu_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button bt_TrangChu;
        private System.Windows.Forms.Button btThongke;
        private System.Windows.Forms.Button btQLNhanVien;
        private System.Windows.Forms.Button btQLDocGia;
        private System.Windows.Forms.Button btQLMuonTra;
        private System.Windows.Forms.Button btQLSach;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btDangXuat;
        private System.Windows.Forms.Panel panel3;
        private QLSach qlSach1;
        private QLNhanVien qlNhanVien1;
        private QLMuonTra qlMuonTra1;
        private QLDocGia qlDocGia1;
        private BaoCao baoCao1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblXinChao;
        private System.Windows.Forms.Button btQLDatSach;
        private home home1;
        private QLDatSach qlDatSach1;
    }
}