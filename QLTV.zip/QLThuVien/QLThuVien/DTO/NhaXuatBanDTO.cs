﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class NhaXuatBanDTO
    {
        public string MaXB { get; set; }
        public string NhaXuatBan { get; set; }
        public string GhiChu { get; set; }
    }
}
