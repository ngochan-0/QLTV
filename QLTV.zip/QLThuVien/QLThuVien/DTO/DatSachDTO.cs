﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class DatSachDTO
    {
        public int MaPhieuDat { get; set; }
        public string MaDG { get; set; }
        public string MaSach { get; set; }
        public DateTime NgayDat { get; set; }
        public string TrangThai { get; set; }
    }
}
