﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO
{
    public class LoaiSachDTO
    {
        public string MaLoai { get; set; }
        public string TenLoaiSach { get; set; }
        public string GhiChu { get; set; }
    }
}
